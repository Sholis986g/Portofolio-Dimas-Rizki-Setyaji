'use client';

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShieldCheck, Sparkles, Terminal } from 'lucide-react';
import { useApp } from '@/context/AppContext';

export default function Preloader() {
  const [loading, setLoading] = useState(true);
  const [step, setStep] = useState(0);
  const { theme } = useApp();

  const steps = [
    { text: 'SYSTEM INITIALIZING...', icon: Terminal },
    { text: 'VERIFYING CSIRT & FORENSIC MODULES...', icon: ShieldCheck },
    { text: 'LOADING VISUAL & CREATIVE PIPELINE...', icon: Sparkles },
    { text: 'AUTHENTICATION VERIFIED · ACCESS GRANTED', icon: ShieldCheck }
  ];

  useEffect(() => {
    // Check session storage to only show full preloader on first session entry
    const hasLoaded = sessionStorage.getItem('drs-preloaded');
    if (hasLoaded) {
      setLoading(false);
      return;
    }

    const interval = setInterval(() => {
      setStep((prev) => {
        if (prev < steps.length - 1) {
          return prev + 1;
        } else {
          clearInterval(interval);
          setTimeout(() => {
            setLoading(false);
            sessionStorage.setItem('drs-preloaded', 'true');
          }, 400);
          return prev;
        }
      });
    }, 400);

    return () => clearInterval(interval);
  }, []);

  return (
    <AnimatePresence>
      {loading && (
        <motion.div
          key="preloader"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, y: -20, transition: { duration: 0.6, ease: [0.16, 1, 0.3, 1] } }}
          className={`fixed inset-0 z-[9999] flex flex-col items-center justify-center ${
            theme === 'light' ? 'bg-white text-zinc-950' : 'bg-[#030712] text-white'
          }`}
        >
          {/* Cyber background aura */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-cyan-500/10 dark:bg-cyan-500/20 blur-[120px] pointer-events-none" />

          {/* Central Animated Monogram Container */}
          <div className="relative flex flex-col items-center">
            {/* Orbital Rings */}
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ repeat: Infinity, duration: 8, ease: 'linear' }}
              className="absolute -inset-6 rounded-full border border-cyan-500/20 border-dashed"
            />
            <motion.div
              animate={{ rotate: -360 }}
              transition={{ repeat: Infinity, duration: 12, ease: 'linear' }}
              className="absolute -inset-10 rounded-full border border-emerald-500/20"
            />

            {/* Core DRS Monogram */}
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.5 }}
              className="relative w-24 h-24 rounded-3xl bg-zinc-100 dark:bg-zinc-900 border-2 border-cyan-500/60 shadow-[0_0_30px_rgba(0,242,254,0.3)] flex flex-col items-center justify-center p-3"
            >
              <span className="text-2xl font-editorial font-extrabold tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-cyan-500 to-emerald-400">
                DRS
              </span>
              <span className="text-[9px] font-mono-code font-bold tracking-widest text-zinc-500 dark:text-zinc-400 uppercase mt-0.5">
                PORTAL
              </span>
            </motion.div>
          </div>

          {/* Name & Role */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2, duration: 0.4 }}
            className="text-center mt-6"
          >
            <h2 className="text-sm font-mono-code font-bold tracking-[0.25em] text-zinc-900 dark:text-white uppercase">
              DIMAS RIZKI SETYAJI
            </h2>
            <p className="text-xs font-mono-code text-cyan-600 dark:text-cyan-400 font-semibold mt-1">
              CREATIVE × SECURITY
            </p>
          </motion.div>

          {/* Progress Bar & Status Ticker */}
          <div className="w-64 max-w-[80vw] mt-8">
            <div className="h-1 w-full bg-zinc-200 dark:bg-white/10 rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-cyan-400 via-blue-500 to-emerald-400 shadow-[0_0_10px_rgba(0,242,254,0.8)]"
                initial={{ width: '0%' }}
                animate={{ width: `${((step + 1) / steps.length) * 100}%` }}
                transition={{ duration: 0.3 }}
              />
            </div>

            <div className="flex items-center justify-between text-[10px] font-mono-code text-zinc-500 dark:text-zinc-400 mt-2.5">
              <span className="flex items-center gap-1.5 text-zinc-700 dark:text-zinc-300 font-medium truncate">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                {steps[step].text}
              </span>
              <span className="font-bold text-cyan-600 dark:text-cyan-400 shrink-0 ml-2">
                {Math.round(((step + 1) / steps.length) * 100)}%
              </span>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
