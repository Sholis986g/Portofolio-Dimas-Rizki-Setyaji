import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono, Space_Grotesk } from "next/font/google";
import "./globals.css";
import { AppProvider } from "@/context/AppContext";
import Preloader from "@/components/Preloader";
import ScrollProgress from "@/components/ScrollProgress";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
  display: "swap",
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
  display: "swap",
});

const spaceGrotesk = Space_Grotesk({
  variable: "--font-space-grotesk",
  subsets: ["latin"],
  display: "swap",
});

export const viewport: Viewport = {
  themeColor: "#030712",
  width: "device-width",
  initialScale: 1,
};

export const metadata: Metadata = {
  title: "Dimas Rizki Setyaji — Creative Designer · Full Stack Developer · Cybersecurity",
  description: "Portfolio of Dimas Rizki Setyaji. Uniting digital design & creative direction, full-stack web engineering (PHP, Laravel, WordPress, Docker), and cybersecurity incident forensics (BPTSI CSIRT, NIST SP 800-86).",
  keywords: [
    "Dimas Rizki Setyaji",
    "Digital Designer",
    "Full Stack Developer",
    "Cybersecurity",
    "BPTSI CSIRT",
    "Digital Forensics",
    "NIST SP 800-86",
    "BPJS Bridging",
    "Docker",
    "Linux",
    "WordPress",
    "PHP Laravel",
    "Graphic Design"
  ],
  authors: [{ name: "Dimas Rizki Setyaji" }],
  openGraph: {
    title: "Dimas Rizki Setyaji — Creative Designer · Developer · Cybersecurity",
    description: "I design digital experiences and understand what's behind them. Creative design meets full-stack engineering and defensive cybersecurity.",
    url: "https://github.com/Sholis986g",
    siteName: "Dimas Rizki Setyaji Portfolio",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html
      lang="id"
      className={`${geistSans.variable} ${geistMono.variable} ${spaceGrotesk.variable} dark scroll-smooth`}
      suppressHydrationWarning
    >
      <body className="font-sans antialiased selection:bg-cyan-400 selection:text-black min-h-screen overflow-x-hidden transition-colors duration-300">
        <AppProvider>
          <Preloader />
          <ScrollProgress />
          {children}
        </AppProvider>
      </body>
    </html>
  );
}
