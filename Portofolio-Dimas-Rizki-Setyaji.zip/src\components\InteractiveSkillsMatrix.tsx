'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { motion } from 'framer-motion';
import {
  Palette,
  ShieldCheck,
  Code2,
  ArrowRight
} from 'lucide-react';
import ToolIcon from '@/components/ToolIcon';
import { useApp } from '@/context/AppContext';
import { DICTIONARY } from '@/data/translations';

export default function InteractiveSkillsMatrix() {
  const [activeCategory, setActiveCategory] = useState<'all' | 'design' | 'dev' | 'security'>('all');
  const { language } = useApp();
  const t = DICTIONARY[language].capabilities;

  const capabilityTracks = [
    {
      id: 'design',
      title: t.trackDesignTitle,
      badge: t.trackDesignBadge,
      color: 'border-cyan-400/40 hover:border-cyan-400',
      glow: 'from-cyan-500/20 to-transparent',
      icon: Palette,
      iconColor: 'text-cyan-400',
      skills: [
        { name: 'Adobe Photoshop', tag: 'Mastery', toolKey: 'photoshop' },
        { name: 'Adobe Illustrator', tag: 'Vector / Print', toolKey: 'illustrator' },
        { name: 'Figma', tag: 'UI/UX Prototyping', toolKey: 'figma' },
        { name: 'Canva Pro', tag: 'Rapid Social', toolKey: 'canva' },
        { name: 'Adobe Lightroom', tag: 'Color Grading', toolKey: 'lightroom' },
        { name: 'Apparel Design', tag: 'CMYK / Screenprint', toolKey: 'apparel' },
      ],
      link: '/design',
      linkText: t.trackDesignLink,
    },
    {
      id: 'dev',
      title: t.trackDevTitle,
      badge: t.trackDevBadge,
      color: 'border-blue-400/40 hover:border-blue-400',
      glow: 'from-blue-500/20 to-transparent',
      icon: Code2,
      iconColor: 'text-blue-400',
      skills: [
        { name: 'PHP & Laravel', tag: 'Secure API / MVC', toolKey: 'laravel' },
        { name: 'WordPress CMS', tag: 'Custom Themes & Logic', toolKey: 'wordpress' },
        { name: 'JavaScript / TS', tag: 'Interactive UI', toolKey: 'javascript' },
        { name: 'Docker Containers', tag: 'Multi-Service Isolation', toolKey: 'docker' },
        { name: 'MySQL Database', tag: 'Indexing & Schema', toolKey: 'mysql' },
        { name: 'Linux / Nginx', tag: 'CLI & Reverse Proxy', toolKey: 'linux' },
      ],
      link: '/security',
      linkText: t.trackDevLink,
    },
    {
      id: 'security',
      title: t.trackSecTitle,
      badge: t.trackSecBadge,
      color: 'border-emerald-400/40 hover:border-emerald-400',
      glow: 'from-emerald-500/20 to-transparent',
      icon: ShieldCheck,
      iconColor: 'text-emerald-400',
      skills: [
        { name: 'NIST SP 800-86', tag: 'Digital Forensics', toolKey: 'nist' },
        { name: 'MITRE ATT&CK', tag: 'Adversary Mapping', toolKey: 'mitre' },
        { name: 'CSIRT Ops', tag: 'Incident Triage', toolKey: 'csirt' },
        { name: 'OWASP Top 10', tag: 'XSS / SQLi Hardening', toolKey: 'owasp' },
        { name: 'OSINT Recon', tag: 'Surface Profiling', toolKey: 'osint' },
        { name: 'BPJS Bridging', tag: 'Secure Healthcare API', toolKey: 'bpjs' },
      ],
      link: '/security',
      linkText: t.trackSecLink,
    },
  ];

  const filteredTracks =
    activeCategory === 'all'
      ? capabilityTracks
      : capabilityTracks.filter((t) => t.id === activeCategory);

  return (
    <section id="capabilities" className="py-20 md:py-28 relative border-t border-black/10 dark:border-white/[0.08]">
      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-12 gap-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="h-2 w-2 rounded-full bg-cyan-500 animate-pulse" />
              <span className="text-xs font-mono-code uppercase tracking-[0.25em] text-cyan-700 dark:text-cyan-400 font-bold">
                {t.eyebrow}
              </span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-editorial font-extrabold tracking-tight text-zinc-950 dark:text-white">
              {t.title}
            </h2>
          </div>

          {/* Interactive Category Filter Pills */}
          <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-zinc-100 dark:bg-white/[0.03] border border-zinc-300 dark:border-white/[0.08] rounded-2xl backdrop-blur-md self-start sm:self-auto shadow-xs">
            {[
              { id: 'all', label: t.filterAll },
              { id: 'design', label: t.filterDesign },
              { id: 'dev', label: t.filterDev },
              { id: 'security', label: t.filterSecurity },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveCategory(tab.id as any)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-mono-code transition-all ${
                  activeCategory === tab.id
                    ? 'bg-zinc-950 text-white dark:bg-white dark:text-black font-bold shadow-md'
                    : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-950 dark:hover:text-white hover:bg-zinc-200/60 dark:hover:bg-white/[0.05] font-semibold'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* 3 Core Capability Modules with Visual Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {filteredTracks.map((track, idx) => {
            const Icon = track.icon;
            return (
              <motion.div
                key={track.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                className={`group relative flex flex-col justify-between rounded-3xl p-6 sm:p-8 cyber-card ${track.color} transition-all duration-300 shadow-md dark:shadow-xl overflow-hidden`}
              >
                {/* Background Ambient Glow */}
                <div
                  className={`absolute -top-12 -right-12 w-40 h-40 bg-gradient-to-br ${track.glow} blur-3xl opacity-30 group-hover:opacity-70 transition-opacity duration-500 pointer-events-none`}
                />

                <div>
                  {/* Top Badge & Icon */}
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-zinc-100 dark:bg-white/[0.05] border border-zinc-300 dark:border-white/10 flex items-center justify-center group-hover:scale-110 transition-transform shadow-xs">
                        <Icon className={`w-6 h-6 ${track.iconColor}`} />
                      </div>
                      <div>
                        <h3 className="text-xl font-editorial font-bold tracking-tight text-zinc-950 dark:text-white">
                          {track.title}
                        </h3>
                        <span className="text-[11px] font-mono-code text-zinc-600 dark:text-zinc-400 font-semibold uppercase tracking-wider">
                          {track.badge}
                        </span>
                      </div>
                    </div>
                    <span className="text-lg font-editorial font-bold text-zinc-400 dark:text-zinc-600 group-hover:text-zinc-700 dark:group-hover:text-zinc-300 transition-colors">
                      0{idx + 1}
                    </span>
                  </div>

                  {/* Skills Badges Grid with Official App / Tool Logos */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 mb-8">
                    {track.skills.map((skill) => (
                      <div
                        key={skill.name}
                        className="p-3 rounded-2xl bg-zinc-50 dark:bg-white/[0.02] border border-zinc-200 dark:border-white/[0.06] hover:bg-zinc-100 dark:hover:bg-white/[0.06] hover:border-zinc-300 dark:hover:border-white/20 transition-all flex items-center gap-3 group/skill shadow-xs"
                      >
                        <div className="w-7 h-7 rounded-lg overflow-hidden shrink-0 flex items-center justify-center shadow-xs">
                          <ToolIcon name={skill.toolKey} className="w-6 h-6" />
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="text-xs font-mono-code font-bold text-zinc-900 dark:text-zinc-100 truncate group-hover/skill:text-cyan-600 dark:group-hover/skill:text-cyan-300 transition-colors">
                            {skill.name}
                          </div>
                          <div className="text-[11px] font-mono-code text-zinc-600 dark:text-zinc-400 truncate font-medium">
                            {skill.tag}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Direct Portfolio Route CTA */}
                <div className="pt-4 border-t border-zinc-200 dark:border-white/[0.08]">
                  <Link
                    href={track.link}
                    className="w-full inline-flex items-center justify-between p-3.5 rounded-2xl bg-zinc-100 dark:bg-white/[0.04] border border-zinc-300 dark:border-transparent hover:bg-zinc-950 hover:text-white dark:hover:bg-white dark:hover:text-black font-mono-code text-xs font-bold text-zinc-900 dark:text-zinc-200 transition-all group/btn shadow-xs"
                  >
                    <span>{track.linkText}</span>
                    <ArrowRight className="w-4 h-4 transition-transform group-hover/btn:translate-x-1" />
                  </Link>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
