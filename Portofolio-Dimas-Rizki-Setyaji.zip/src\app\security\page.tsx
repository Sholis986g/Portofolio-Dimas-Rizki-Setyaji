'use client';

import React from 'react';
import Navbar from '@/components/Navbar';
import Publications from '@/components/Publications';
import SecurityLab from '@/components/SecurityLab';
import Contact from '@/components/Contact';
import Footer from '@/components/Footer';
import PageTransition from '@/components/PageTransition';
import { Shield } from 'lucide-react';
import { useApp } from '@/context/AppContext';

export default function SecurityPage() {
  const { language } = useApp();

  return (
    <PageTransition>
      <main className="min-h-screen bg-[var(--bg-primary)] text-[var(--text-primary)] flex flex-col relative selection:bg-emerald-400 selection:text-black">
        {/* Navigation */}
        <Navbar />

      {/* Hero Banner for Security Portfolio */}
      <section className="relative pt-32 pb-16 md:pt-40 md:pb-24 border-b border-black/10 dark:border-white/[0.08] overflow-hidden bg-gradient-to-b from-black/[0.03] to-transparent dark:from-[#06101c] dark:to-[#04060c]">
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[450px] bg-gradient-to-tr from-emerald-500/10 via-cyan-500/10 to-transparent blur-[160px] pointer-events-none" />
        <div className="absolute inset-0 bg-grid-pattern opacity-15 dark:opacity-25 pointer-events-none" />

        <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
          <div className="flex items-center gap-2 mb-4">
            <span className="p-1 rounded bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 border border-emerald-500/30">
              <Shield className="w-3.5 h-3.5" />
            </span>
            <span className="text-xs font-mono-code uppercase tracking-[0.25em] text-emerald-700 dark:text-emerald-400 font-bold">
              {language === 'id' ? 'LAB PERTAHANAN CSIRT & RISET KEAMANAN' : 'CSIRT DEFENSIVE & SECURITY RESEARCH LAB'}
            </span>
          </div>

          <h1 className="font-editorial text-4xl sm:text-6xl md:text-7xl font-extrabold tracking-tight mb-6 leading-[1.05] text-zinc-950 dark:text-white">
            {language === 'id' ? (
              <>
                KEAMANAN SIBER, FORENSIK DIGITAL <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 via-cyan-600 to-blue-600 dark:from-emerald-500 dark:via-cyan-500 dark:to-blue-500">
                  & ARSITEKTUR DEFENSIVE.
                </span>
              </>
            ) : (
              <>
                CYBERSECURITY, DIGITAL FORENSICS <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 via-cyan-600 to-blue-600 dark:from-emerald-500 dark:via-cyan-500 dark:to-blue-500">
                  & DEFENSIVE ARCHITECTURE.
                </span>
              </>
            )}
          </h1>

          <p className="text-base sm:text-lg text-zinc-700 dark:text-zinc-300 font-normal leading-relaxed max-w-2xl mb-8">
            {language === 'id'
              ? 'Dokumentasi riset forensik digital, hardening infrastruktur server web, dan operasi Computer Security Incident Response Team (CSIRT) oleh Dimas Rizki Setyaji — berbasis standar NIST SP 800-86, OWASP Web Security, dan audit integritas SHA-256.'
              : 'Documentation of digital forensics research, web server infrastructure hardening, and Computer Security Incident Response Team (CSIRT) operations by Dimas Rizki Setyaji — grounded in NIST SP 800-86, OWASP Web Security, and SHA-256 integrity audits.'}
          </p>

          <div className="flex flex-wrap items-center gap-4 text-xs font-mono-code text-zinc-600 dark:text-zinc-400">
            <span className="px-3 py-1 rounded-full bg-emerald-100/90 border border-emerald-300 text-emerald-800 dark:bg-emerald-500/10 dark:border-emerald-500/20 dark:text-emerald-300 font-medium">
              🛡 NIST SP 800-86 Memory Forensics
            </span>
            <span className="px-3 py-1 rounded-full bg-zinc-100 dark:bg-white/[0.04] border border-zinc-300 dark:border-white/10 text-zinc-800 dark:text-zinc-200 font-medium">
              🛡 OWASP Top 10 Web Hardening
            </span>
            <span className="px-3 py-1 rounded-full bg-zinc-100 dark:bg-white/[0.04] border border-zinc-300 dark:border-white/10 text-zinc-800 dark:text-zinc-200 font-medium">
              🛡 Docker Egress & Bridge Isolation
            </span>
          </div>
        </div>
      </section>

      {/* Security Lab Core Sandbox & Interactive Terminal */}
      <SecurityLab />

      {/* Peer-Reviewed Publications */}
      <Publications />

      {/* Contact */}
      <Contact />

      {/* Footer */}
      <Footer />
    </main>
    </PageTransition>
  );
}
