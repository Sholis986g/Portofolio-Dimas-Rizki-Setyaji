'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Image from 'next/image';
import { ArrowUpRight, Check, X, Shield, Terminal, Layers, Sparkles, Filter, ExternalLink } from 'lucide-react';
import { PORTFOLIO_DATA, Project } from '@/data/portfolio-data';

export default function Projects() {
  const { projects } = PORTFOLIO_DATA;
  const [selectedTag, setSelectedTag] = useState<'ALL' | 'DEVELOPMENT' | 'CYBERSECURITY' | 'DESIGN'>('ALL');
  const [activeModalProject, setActiveModalProject] = useState<Project | null>(null);

  const filteredProjects = selectedTag === 'ALL'
    ? projects
    : projects.filter((p) => p.tag === selectedTag);

  return (
    <section id="work" className="py-24 md:py-32 relative border-t border-white/[0.06] bg-[#050505]">
      {/* Atmosphere */}
      <div className="absolute top-1/3 right-0 w-[500px] h-[500px] bg-blue-500/5 blur-[160px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 md:px-12">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="h-1.5 w-1.5 rounded-full bg-cyan-400" />
              <span className="text-xs font-mono-code uppercase tracking-[0.25em] text-zinc-400">
                04 / DETAILED CASE STUDIES
              </span>
            </div>
            <h2 className="text-4xl md:text-6xl font-editorial font-extrabold tracking-tight text-white">
              FEATURED PROJECTS
            </h2>
          </div>

          {/* Filter Pills */}
          <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-white/[0.03] border border-white/[0.08] rounded-2xl backdrop-blur-md">
            {(['ALL', 'DEVELOPMENT', 'CYBERSECURITY', 'DESIGN'] as const).map((tag) => (
              <button
                key={tag}
                onClick={() => setSelectedTag(tag)}
                className={`px-4 py-2 rounded-xl text-xs font-mono-code transition-all ${
                  selectedTag === tag
                    ? 'bg-white text-black font-semibold shadow-md'
                    : 'text-zinc-400 hover:text-white hover:bg-white/[0.05]'
                }`}
              >
                {tag}
              </button>
            ))}
          </div>
        </div>

        {/* Rich Image-Driven Case Study Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {filteredProjects.map((project, idx) => (
            <motion.div
              key={project.id}
              layout
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: idx * 0.1 }}
              className="group relative flex flex-col justify-between rounded-3xl bg-[#090d16]/80 border border-white/[0.08] hover:border-cyan-400/40 transition-all duration-500 overflow-hidden shadow-xl"
            >
              {/* Card Image Banner */}
              <div
                onClick={() => setActiveModalProject(project)}
                className="relative w-full h-56 sm:h-64 overflow-hidden bg-black/60 cursor-pointer"
              >
                <Image
                  src={project.image}
                  alt={project.title}
                  fill
                  sizes="(max-width: 768px) 100vw, 50vw"
                  className="object-cover object-top group-hover:scale-105 transition-transform duration-700 ease-out"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#090d16] via-transparent to-transparent opacity-80" />

                {/* Floating Category & Year Badges */}
                <div className="absolute top-4 left-4 flex items-center gap-2">
                  <span className="px-3 py-1 text-[10px] font-mono-code rounded-full bg-black/70 border border-white/15 text-cyan-300 backdrop-blur-md">
                    {project.category}
                  </span>
                </div>
                <div className="absolute top-4 right-4">
                  <span className="px-2.5 py-1 text-[10px] font-mono-code rounded-full bg-black/70 border border-white/10 text-zinc-300 backdrop-blur-md">
                    {project.year}
                  </span>
                </div>
              </div>

              {/* Card Body */}
              <div className="p-6 md:p-8 flex flex-col justify-between flex-1">
                <div>
                  <h3
                    onClick={() => setActiveModalProject(project)}
                    className="text-2xl font-editorial font-bold text-white mb-2 group-hover:text-cyan-200 transition-colors cursor-pointer leading-tight"
                  >
                    {project.title}
                  </h3>

                  <p className="text-xs sm:text-sm text-zinc-300 font-light leading-relaxed mb-6 line-clamp-2">
                    {project.shortDescription}
                  </p>

                  {/* Key Metrics Row */}
                  {project.metrics && (
                    <div className="grid grid-cols-3 gap-2 mb-6 p-3 rounded-2xl bg-black/40 border border-white/[0.04] text-center">
                      {project.metrics.map((m, mIdx) => (
                        <div key={mIdx} className="flex flex-col">
                          <span className="text-sm sm:text-base font-editorial font-bold text-white">
                            {m.value}
                          </span>
                          <span className="text-[9px] font-mono-code text-zinc-400 uppercase truncate">
                            {m.label}
                          </span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Card Footer: Technologies & Case Study Button */}
                <div className="pt-4 border-t border-white/[0.08] flex flex-wrap items-center justify-between gap-3">
                  <div className="flex flex-wrap gap-1">
                    {project.technologies.slice(0, 3).map((tech) => (
                      <span
                        key={tech}
                        className="px-2 py-0.5 text-[9px] font-mono-code rounded bg-white/[0.03] text-zinc-400 border border-white/[0.05]"
                      >
                        {tech}
                      </span>
                    ))}
                    {project.technologies.length > 3 && (
                      <span className="px-2 py-0.5 text-[9px] font-mono-code rounded bg-white/[0.03] text-zinc-500">
                        +{project.technologies.length - 3}
                      </span>
                    )}
                  </div>

                  <button
                    onClick={() => setActiveModalProject(project)}
                    className="inline-flex items-center gap-1 text-xs font-mono-code font-medium text-cyan-400 hover:text-cyan-300 transition-colors"
                  >
                    <span>EXPLORE SPECS</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Case Study Fullscreen Modal */}
      <AnimatePresence>
        {activeModalProject && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 md:p-8 bg-black/85 backdrop-blur-2xl">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-3xl bg-[#090d16] border border-white/20 p-6 md:p-10 shadow-2xl"
            >
              {/* Close Button */}
              <button
                onClick={() => setActiveModalProject(null)}
                className="absolute top-6 right-6 z-20 p-2.5 rounded-full bg-white/[0.08] hover:bg-white/[0.2] text-zinc-300 hover:text-white transition-colors"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>

              {/* Modal Top Image Banner */}
              <div className="relative w-full h-56 sm:h-72 rounded-2xl overflow-hidden bg-black/70 mb-6 border border-white/10">
                <Image
                  src={activeModalProject.image}
                  alt={activeModalProject.title}
                  fill
                  className="object-cover"
                />
              </div>

              {/* Modal Category & Title */}
              <div className="flex items-center gap-3 mb-2">
                <span className="px-3 py-1 text-xs font-mono-code rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300">
                  {activeModalProject.category}
                </span>
                <span className="text-xs font-mono-code text-zinc-400">
                  YEAR {activeModalProject.year}
                </span>
              </div>

              <h3 className="text-2xl sm:text-3xl font-editorial font-bold text-white mb-4">
                {activeModalProject.title}
              </h3>

              <p className="text-sm sm:text-base text-zinc-300 font-light leading-relaxed mb-6">
                {activeModalProject.fullDescription}
              </p>

              {/* Impact Callout */}
              <div className="p-4 rounded-2xl bg-cyan-500/[0.05] border border-cyan-500/20 mb-6">
                <span className="text-[10px] font-mono-code text-cyan-400 uppercase tracking-widest block mb-1">
                  CORE IMPACT & OUTCOME
                </span>
                <p className="text-sm font-editorial text-white">
                  {activeModalProject.impact}
                </p>
              </div>

              {/* Gallery Thumbnails inside modal if available */}
              {activeModalProject.galleryImages && activeModalProject.galleryImages.length > 1 && (
                <div className="mb-6">
                  <span className="text-[10px] font-mono-code text-zinc-400 uppercase tracking-widest block mb-3">
                    VISUAL ARTIFACTS
                  </span>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {activeModalProject.galleryImages.map((img, gIdx) => (
                      <div key={gIdx} className="relative h-28 rounded-xl overflow-hidden border border-white/10 bg-black/50">
                        <Image src={img} alt="Artifact" fill className="object-cover" />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Architecture Details & Security Notes */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                {activeModalProject.architectureDetails && (
                  <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/[0.06]">
                    <span className="text-[10px] font-mono-code text-zinc-400 uppercase tracking-widest block mb-2">
                      ARCHITECTURE & IMPLEMENTATION
                    </span>
                    <div className="space-y-1.5">
                      {activeModalProject.architectureDetails.map((detail, dIdx) => (
                        <div key={dIdx} className="text-xs text-zinc-300 flex items-start gap-2">
                          <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                          <span>{detail}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {activeModalProject.securityConsiderations && (
                  <div className="p-4 rounded-2xl bg-white/[0.02] border border-white/[0.06]">
                    <span className="text-[10px] font-mono-code text-emerald-400 uppercase tracking-widest block mb-2">
                      DEFENSIVE SECURITY POSTURE
                    </span>
                    <div className="space-y-1.5">
                      {activeModalProject.securityConsiderations.map((sec, sIdx) => (
                        <div key={sIdx} className="text-xs text-zinc-300 flex items-start gap-2">
                          <Shield className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                          <span>{sec}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Technologies */}
              <div className="pt-4 border-t border-white/[0.08] flex flex-wrap gap-2">
                {activeModalProject.technologies.map((t) => (
                  <span
                    key={t}
                    className="px-3 py-1 text-xs font-mono-code rounded-lg bg-white/[0.04] border border-white/10 text-zinc-200"
                  >
                    {t}
                  </span>
                ))}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
