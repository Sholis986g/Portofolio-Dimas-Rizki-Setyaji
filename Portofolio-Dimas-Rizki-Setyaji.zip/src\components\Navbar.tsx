'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, ArrowUpRight, Palette, Shield, Home, Sun, Moon, Languages } from 'lucide-react';
import { useApp } from '@/context/AppContext';
import { DICTIONARY } from '@/data/translations';

interface NavbarProps {
  activeSection?: string;
}

export default function Navbar({ activeSection = '' }: NavbarProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const pathname = usePathname();
  const { theme, toggleTheme, language, toggleLanguage } = useApp();
  const t = DICTIONARY[language].nav;

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 40);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const isHome = pathname === '/';
  const isDesign = pathname === '/design';
  const isSecurity = pathname === '/security';

  const pageLinks = [
    { name: t.overview, href: '/', icon: Home, active: isHome },
    { name: t.designLab, href: '/design', icon: Palette, active: isDesign, accent: 'text-cyan-400' },
    { name: t.cyberSecurity, href: '/security', icon: Shield, active: isSecurity, accent: 'text-emerald-400' },
  ];

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isScrolled
            ? theme === 'light'
              ? 'py-3 bg-white/85 backdrop-blur-xl border-b border-black/10 shadow-[0_10px_30px_rgba(0,0,0,0.06)]'
              : 'py-3 bg-[#050505]/85 backdrop-blur-xl border-b border-white/[0.08] shadow-[0_10px_30px_rgba(0,0,0,0.8)]'
            : 'py-5 bg-transparent'
        }`}
      >
        <div className="max-w-7xl mx-auto px-6 md:px-12 flex items-center justify-between">
          {/* Brand Logo & Tag */}
          <Link
            href="/"
            className="group flex items-center gap-3 transition-transform hover:scale-[0.99]"
          >
            <div className="relative w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500/20 to-blue-500/10 border border-cyan-400/30 flex items-center justify-center overflow-hidden group-hover:border-cyan-400 transition-colors">
              <span className={`font-editorial font-bold text-sm tracking-tighter ${theme === 'light' ? 'text-zinc-900' : 'text-white'}`}>
                DRS
              </span>
              <div className="absolute inset-0 bg-cyan-400/10 opacity-0 group-hover:opacity-100 transition-opacity" />
            </div>
            <div className="flex flex-col">
              <span className={`font-editorial font-bold tracking-tight text-sm md:text-base group-hover:text-cyan-400 transition-colors ${theme === 'light' ? 'text-zinc-900' : 'text-white'}`}>
                DIMAS RIZKI SETYAJI
              </span>
              <span className="text-[10px] tracking-[0.2em] text-zinc-500 font-mono-code -mt-1 hidden sm:inline">
                {isDesign ? t.subDesign : isSecurity ? t.subSecurity : t.subDefault}
              </span>
            </div>
          </Link>

          {/* Dedicated Mode/Page Switcher */}
          <nav className={`hidden md:flex items-center gap-1 p-1 rounded-full backdrop-blur-md ${theme === 'light' ? 'bg-black/[0.04] border border-black/10' : 'bg-white/[0.03] border border-white/[0.08]'}`}>
            {pageLinks.map((link) => {
              const Icon = link.icon;
              return (
                <Link
                  key={link.name}
                  href={link.href}
                  className={`flex items-center gap-2 px-4 py-1.5 text-xs font-mono-code tracking-wider rounded-full transition-all ${
                    link.active
                      ? theme === 'light'
                        ? 'bg-zinc-900 text-white font-bold shadow-md'
                        : 'bg-white text-black font-bold shadow-[0_0_20px_rgba(255,255,255,0.25)]'
                      : theme === 'light'
                      ? 'text-zinc-600 hover:text-zinc-900 hover:bg-black/[0.04]'
                      : 'text-zinc-400 hover:text-white hover:bg-white/[0.06]'
                  }`}
                >
                  <Icon className={`w-3.5 h-3.5 ${link.active ? (theme === 'light' ? 'text-white' : 'text-black') : link.accent || 'text-zinc-400'}`} />
                  <span>{link.name}</span>
                </Link>
              );
            })}
          </nav>

          {/* Controls (Theme Toggle, Language Switcher, Connect) */}
          <div className="hidden sm:flex items-center gap-2.5">
            {/* Language Switcher Button */}
            <button
              onClick={toggleLanguage}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-mono-code font-bold transition-all ${
                theme === 'light'
                  ? 'bg-black/[0.05] hover:bg-black/10 text-zinc-800 border border-black/10'
                  : 'bg-white/[0.05] hover:bg-white/10 text-zinc-300 border border-white/10'
              }`}
              title={language === 'id' ? 'Switch to English' : 'Ganti ke Bahasa Indonesia'}
            >
              <Languages className="w-3.5 h-3.5 text-cyan-400" />
              <span className="uppercase">{language === 'id' ? 'ID' : 'EN'}</span>
            </button>

            {/* Dark / Light Theme Toggle Button */}
            <button
              onClick={toggleTheme}
              className={`p-2 rounded-full transition-all ${
                theme === 'light'
                  ? 'bg-black/[0.05] hover:bg-black/10 text-amber-600 border border-black/10'
                  : 'bg-white/[0.05] hover:bg-white/10 text-cyan-300 border border-white/10'
              }`}
              title={theme === 'light' ? 'Beralih ke Dark Mode' : 'Switch to Light Mode'}
            >
              {theme === 'light' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
            </button>

            {/* Connect CTA */}
            <a
              href="#contact"
              className={`group relative inline-flex items-center gap-1.5 px-4 py-1.5 text-xs font-mono-code font-bold rounded-full transition-all duration-300 ${
                theme === 'light'
                  ? 'bg-zinc-900 text-white hover:bg-cyan-600 hover:shadow-md'
                  : 'bg-white text-black hover:bg-cyan-300 hover:shadow-[0_0_20px_rgba(0,242,254,0.4)]'
              }`}
            >
              <span>{t.connect}</span>
              <ArrowUpRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </a>
          </div>

          {/* Mobile Menu & Quick Toggle */}
          <div className="flex sm:hidden items-center gap-2">
            <button
              onClick={toggleLanguage}
              className="px-2 py-1 text-[11px] font-mono-code font-bold rounded bg-cyan-500/10 text-cyan-400 border border-cyan-400/20"
            >
              {language.toUpperCase()}
            </button>
            <button
              onClick={toggleTheme}
              className="p-1.5 rounded bg-white/[0.05] border border-white/10 text-zinc-300"
            >
              {theme === 'light' ? <Moon className="w-4 h-4 text-zinc-900" /> : <Sun className="w-4 h-4 text-cyan-300" />}
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className={`p-2 rounded-lg border ${theme === 'light' ? 'bg-black/5 border-black/10 text-zinc-900' : 'bg-white/[0.05] border-white/10 text-zinc-300'}`}
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Drawer */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.2 }}
            className={`fixed inset-0 z-40 backdrop-blur-2xl pt-24 px-6 pb-12 flex flex-col justify-between md:hidden ${
              theme === 'light' ? 'bg-white/95 text-zinc-900' : 'bg-[#050505]/95 text-white'
            }`}
          >
            <div className="flex flex-col gap-3">
              <div className="text-[10px] font-mono-code text-zinc-500 tracking-[0.25em] mb-2 px-2">
                {t.selectLab}
              </div>
              {pageLinks.map((link, idx) => {
                const Icon = link.icon;
                return (
                  <Link
                    key={link.name}
                    href={link.href}
                    onClick={() => setMobileMenuOpen(false)}
                    className={`flex items-center justify-between p-4 rounded-2xl border transition-all ${
                      link.active
                        ? theme === 'light'
                          ? 'bg-zinc-900 text-white font-bold border-zinc-900'
                          : 'bg-white text-black font-bold border-white'
                        : theme === 'light'
                        ? 'bg-black/[0.02] border-black/[0.08] text-zinc-800 hover:bg-black/[0.05]'
                        : 'bg-white/[0.02] border-white/[0.06] text-zinc-200 hover:bg-white/[0.06]'
                    }`}
                  >
                    <span className="flex items-center gap-3">
                      <Icon className={`w-4 h-4 ${link.active ? (theme === 'light' ? 'text-white' : 'text-black') : 'text-cyan-400'}`} />
                      <span className="font-editorial text-lg">{link.name}</span>
                    </span>
                    <span className="text-xs font-mono-code text-zinc-500">0{idx + 1}</span>
                  </Link>
                );
              })}
            </div>

            <div className="pt-6 border-t border-black/10 dark:border-white/10 flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <button
                  onClick={toggleLanguage}
                  className="px-4 py-2 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-400/20 text-xs font-mono-code font-bold"
                >
                  BAHASA: {language === 'id' ? 'INDONESIA' : 'ENGLISH'}
                </button>
                <button
                  onClick={toggleTheme}
                  className="px-4 py-2 rounded-xl bg-white/[0.05] dark:bg-white/10 text-xs font-mono-code font-bold flex items-center gap-2"
                >
                  {theme === 'light' ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4 text-cyan-400" />}
                  <span>{theme.toUpperCase()} MODE</span>
                </button>
              </div>

              <a
                href="#contact"
                onClick={() => setMobileMenuOpen(false)}
                className={`w-full py-3.5 font-semibold text-center rounded-xl text-sm transition-colors ${
                  theme === 'light'
                    ? 'bg-zinc-900 text-white hover:bg-cyan-600'
                    : 'bg-white text-black hover:bg-cyan-300'
                }`}
              >
                {t.letsTalk}
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
