'use client';

import React, { useEffect, useRef, useState } from 'react';

export default function InteractiveVisualSystem() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [activeMode, setActiveMode] = useState<'creative' | 'technical'>('creative');

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = canvas.offsetWidth);
    let height = (canvas.height = canvas.offsetHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = canvas.offsetWidth;
      height = canvas.height = canvas.offsetHeight;
    };

    window.addEventListener('resize', handleResize);

    // Nodes for interactive geometric/nodal grid
    const nodeCount = 36;
    const nodes: {
      x: number;
      y: number;
      vx: number;
      vy: number;
      radius: number;
      ringSize: number;
      angle: number;
      type: 'dot' | 'square' | 'poly';
    }[] = [];

    for (let i = 0; i < nodeCount; i++) {
      nodes.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.45,
        vy: (Math.random() - 0.5) * 0.45,
        radius: Math.random() * 2 + 1.5,
        ringSize: Math.random() * 24 + 10,
        angle: Math.random() * Math.PI * 2,
        type: i % 3 === 0 ? 'poly' : i % 2 === 0 ? 'square' : 'dot',
      });
    }

    let mouseX = width / 2;
    let mouseY = height / 2;
    let targetMouseX = width / 2;
    let targetMouseY = height / 2;

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      targetMouseX = e.clientX - rect.left;
      targetMouseY = e.clientY - rect.top;
    };

    canvas.addEventListener('mousemove', handleMouseMove);

    let time = 0;

    const render = () => {
      time += 0.015;
      mouseX += (targetMouseX - mouseX) * 0.05;
      mouseY += (targetMouseY - mouseY) * 0.05;

      ctx.clearRect(0, 0, width, height);

      // Draw subtle technical grid backdrop
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.025)';
      ctx.lineWidth = 1;
      const step = 40;
      for (let x = 0; x < width; x += step) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
      }
      for (let y = 0; y < height; y += step) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      // Draw central dynamic orbital rings (Minimal Futuristic Apple/Awwwards style)
      const centerX = width / 2 + (mouseX - width / 2) * 0.08;
      const centerY = height / 2 + (mouseY - height / 2) * 0.08;

      // Outer glowing gradient sphere
      const gradient = ctx.createRadialGradient(
        centerX,
        centerY,
        10,
        centerX,
        centerY,
        width * 0.45
      );
      gradient.addColorStop(0, 'rgba(0, 242, 254, 0.08)');
      gradient.addColorStop(0.5, 'rgba(79, 172, 254, 0.03)');
      gradient.addColorStop(1, 'transparent');

      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(centerX, centerY, width * 0.45, 0, Math.PI * 2);
      ctx.fill();

      // Precision geometry rings
      const rings = [
        { r: 90, speed: 0.01, dash: [4, 12], alpha: 0.25, color: '#00F2FE' },
        { r: 140, speed: -0.008, dash: [1, 6], alpha: 0.2, color: '#FFFFFF' },
        { r: 190, speed: 0.005, dash: [18, 20], alpha: 0.15, color: '#4FACFE' },
        { r: 240, speed: -0.003, dash: [2, 16], alpha: 0.1, color: '#FFFFFF' },
      ];

      rings.forEach((ring) => {
        ctx.save();
        ctx.translate(centerX, centerY);
        ctx.rotate(time * ring.speed * 40);
        ctx.strokeStyle = ring.color;
        ctx.globalAlpha = ring.alpha;
        ctx.lineWidth = 1;
        ctx.setLineDash(ring.dash);
        ctx.beginPath();
        ctx.arc(0, 0, ring.r, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      });

      // Update and connect nodes
      for (let i = 0; i < nodes.length; i++) {
        const node = nodes[i];

        node.x += node.vx;
        node.y += node.vy;

        if (node.x < 0 || node.x > width) node.vx *= -1;
        if (node.y < 0 || node.y > height) node.vy *= -1;

        // Subtle mouse repulsion/attraction
        const dx = mouseX - node.x;
        const dy = mouseY - node.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 140) {
          node.x -= (dx / dist) * 0.4;
          node.y -= (dy / dist) * 0.4;
        }

        // Draw connections
        for (let j = i + 1; j < nodes.length; j++) {
          const node2 = nodes[j];
          const cdx = node.x - node2.x;
          const cdy = node.y - node2.y;
          const cdist = Math.sqrt(cdx * cdx + cdy * cdy);

          if (cdist < 100) {
            ctx.strokeStyle = '#00F2FE';
            ctx.globalAlpha = (1 - cdist / 100) * 0.18;
            ctx.lineWidth = 0.8;
            ctx.setLineDash([]);
            ctx.beginPath();
            ctx.moveTo(node.x, node.y);
            ctx.lineTo(node2.x, node2.y);
            ctx.stroke();
          }
        }

        // Draw node glyph
        ctx.save();
        ctx.translate(node.x, node.y);
        ctx.globalAlpha = 0.5;

        if (node.type === 'square') {
          ctx.strokeStyle = '#FFFFFF';
          ctx.strokeRect(-2, -2, 4, 4);
        } else if (node.type === 'poly') {
          ctx.strokeStyle = '#00F2FE';
          ctx.beginPath();
          ctx.moveTo(0, -3);
          ctx.lineTo(3, 3);
          ctx.lineTo(-3, 3);
          ctx.closePath();
          ctx.stroke();
        } else {
          ctx.fillStyle = '#FFFFFF';
          ctx.beginPath();
          ctx.arc(0, 0, node.radius, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
      }

      // Draw subtle telemetry crosshairs
      ctx.globalAlpha = 0.2;
      ctx.strokeStyle = '#FFFFFF';
      ctx.setLineDash([2, 4]);

      ctx.beginPath();
      ctx.moveTo(mouseX - 15, mouseY);
      ctx.lineTo(mouseX + 15, mouseY);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(mouseX, mouseY - 15);
      ctx.lineTo(mouseX, mouseY + 15);
      ctx.stroke();

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      if (canvas) canvas.removeEventListener('mousemove', handleMouseMove);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <div className="relative w-full h-full min-h-[420px] md:min-h-[540px] flex items-center justify-center">
      {/* Background canvas */}
      <canvas
        ref={canvasRef}
        className="w-full h-full absolute inset-0 cursor-crosshair rounded-3xl"
      />

      {/* Floating telemetry cards */}
      <div className="absolute top-4 right-4 md:top-6 md:right-6 pointer-events-none">
        <div className="bg-[#050816]/75 border border-white/10 backdrop-blur-md rounded-lg px-3 py-2 text-[11px] font-mono-code flex flex-col gap-1 text-zinc-400">
          <div className="flex items-center gap-2 text-zinc-200">
            <span className="h-1.5 w-1.5 rounded-full bg-cyan-400 animate-ping" />
            <span>INTERACTIVE SYSTEM</span>
          </div>
          <div className="text-[9px] text-zinc-500">CANVAS LATENCY: &lt;1ms · 60 FPS</div>
        </div>
      </div>

      <div className="absolute bottom-4 left-4 md:bottom-6 md:left-6 pointer-events-none">
        <div className="bg-[#050816]/75 border border-white/10 backdrop-blur-md rounded-lg px-3.5 py-2 text-[11px] font-mono-code flex items-center gap-3 text-zinc-300">
          <div className="flex flex-col">
            <span className="text-[9px] text-zinc-500 uppercase tracking-widest">LAYER DUALITY</span>
            <span className="text-white font-medium text-xs">VISUAL × ARCHITECTURE</span>
          </div>
          <span className="text-cyan-400">01 / 02</span>
        </div>
      </div>
    </div>
  );
}
