'use client';

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, ArrowUpRight, Copy, Check, Send } from 'lucide-react';
import { PORTFOLIO_DATA } from '@/data/portfolio-data';
import { useApp } from '@/context/AppContext';
import { DICTIONARY } from '@/data/translations';

export default function Contact() {
  const { profile } = PORTFOLIO_DATA;
  const { language } = useApp();
  const t = DICTIONARY[language].contact;

  const [copiedEmail, setCopiedEmail] = useState(false);
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    track: t.optDesign,
    message: ''
  });

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(profile.socialLinks.email);
    setCopiedEmail(true);
    setTimeout(() => setCopiedEmail(false), 2500);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormSubmitted(true);
  };

  return (
    <section id="contact" className="py-20 md:py-28 relative border-t border-zinc-200 dark:border-white/[0.08]">
      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-12 gap-4 pb-4 border-b border-zinc-200 dark:border-white/[0.06]">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="h-2 w-2 rounded-full bg-cyan-500 animate-pulse" />
              <span className="text-xs font-mono-code uppercase tracking-[0.25em] text-cyan-700 dark:text-cyan-400 font-bold">
                {t.eyebrow}
              </span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-editorial font-extrabold tracking-tight text-zinc-950 dark:text-white">
              {t.title}
            </h2>
          </div>
          <span className="text-xs font-mono-code text-emerald-700 dark:text-emerald-400 font-bold">
            {t.status}
          </span>
        </div>

        {/* 2-Column Clean Contact Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left: Quick Connect & Socials (5 cols) */}
          <div className="lg:col-span-5 flex flex-col gap-4">
            {/* Direct Email Card */}
            <div className="p-6 sm:p-8 rounded-3xl cyber-card shadow-xs">
              <span className="text-xs font-mono-code text-zinc-600 dark:text-zinc-400 font-bold uppercase tracking-wider block mb-2">
                {t.inboxTitle}
              </span>
              <div className="flex items-center justify-between gap-3 p-3 rounded-2xl bg-zinc-50 dark:bg-white/[0.03] border border-zinc-200 dark:border-white/[0.06] mb-4">
                <span className="text-xs sm:text-sm font-mono-code font-semibold text-zinc-900 dark:text-zinc-100 select-all truncate">
                  {profile.socialLinks.email}
                </span>
                <button
                  onClick={handleCopyEmail}
                  className="p-2 rounded-xl bg-zinc-100 dark:bg-white/[0.06] hover:bg-cyan-500 hover:text-white text-zinc-700 dark:text-zinc-300 transition-colors shrink-0"
                  title="Copy email"
                >
                  {copiedEmail ? (
                    <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-500" />
                  ) : (
                    <Copy className="w-4 h-4" />
                  )}
                </button>
              </div>

              <a
                href={`mailto:${profile.socialLinks.email}`}
                className="w-full inline-flex items-center justify-center gap-2 py-3 rounded-2xl bg-zinc-950 text-white dark:bg-white dark:text-black font-bold text-xs font-mono-code hover:bg-cyan-600 dark:hover:bg-cyan-400 hover:text-white dark:hover:text-black transition-colors shadow-md"
              >
                <span>{t.openEmail}</span>
                <ArrowUpRight className="w-4 h-4" />
              </a>
            </div>

            {/* Social Matrix */}
            <div className="grid grid-cols-2 gap-2.5">
              {[
                { name: 'Contra', tag: 'Freelance Hub', href: profile.socialLinks.contra, accent: 'text-cyan-600 dark:text-cyan-400' },
                { name: 'LinkedIn', tag: 'Profile', href: profile.socialLinks.linkedin, accent: 'text-blue-600 dark:text-blue-400' },
                { name: 'GitHub', tag: 'Repositories', href: profile.socialLinks.github, accent: 'text-zinc-800 dark:text-zinc-200' },
                { name: 'Instagram', tag: 'Design Work', href: profile.socialLinks.instagram, accent: 'text-purple-600 dark:text-purple-400' },
              ].map((social) => (
                <a
                  key={social.name}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-4 rounded-2xl cyber-card flex flex-col justify-between group shadow-xs hover:border-cyan-500 transition-colors"
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-editorial font-bold text-zinc-950 dark:text-white group-hover:text-cyan-600 dark:group-hover:text-cyan-300">
                      {social.name}
                    </span>
                    <ArrowUpRight className="w-3.5 h-3.5 text-zinc-500 group-hover:text-cyan-600" />
                  </div>
                  <span className="text-[11px] font-mono-code text-zinc-600 dark:text-zinc-400 font-medium">{social.tag}</span>
                </a>
              ))}
            </div>
          </div>

          {/* Right: Message Dispatch Form (7 cols) */}
          <div className="lg:col-span-7">
            <div className="p-6 sm:p-8 rounded-3xl cyber-card shadow-xs">
              {formSubmitted ? (
                <div className="py-12 flex flex-col items-center text-center">
                  <div className="w-14 h-14 rounded-2xl bg-emerald-100/90 dark:bg-emerald-500/10 border border-emerald-300 dark:border-emerald-500/30 flex items-center justify-center text-emerald-700 dark:text-emerald-400 mb-3">
                    <Check className="w-7 h-7" />
                  </div>
                  <h4 className="text-xl font-editorial font-bold mb-1 text-zinc-950 dark:text-white">
                    {t.successTitle}
                  </h4>
                  <p className="text-xs font-mono-code text-zinc-600 dark:text-zinc-400 max-w-xs mb-4">
                    {t.successDesc}
                  </p>
                  <button
                    onClick={() => {
                      setFormSubmitted(false);
                      setFormData({ name: '', email: '', track: t.optDesign, message: '' });
                    }}
                    className="px-4 py-2 rounded-xl bg-zinc-100 dark:bg-white/[0.05] text-xs font-mono-code text-zinc-800 dark:text-zinc-300 hover:text-black dark:hover:text-white font-medium"
                  >
                    {t.sendAnother}
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-3.5">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="text-[11px] font-mono-code text-zinc-700 dark:text-zinc-400 font-bold block mb-1.5">
                        {t.nameLabel}
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="Dimas / Partner"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-50 dark:bg-white/[0.03] border border-zinc-300 dark:border-white/[0.08] text-xs font-mono-code text-zinc-900 dark:text-white focus:outline-none focus:border-cyan-500 transition-colors"
                      />
                    </div>
                    <div>
                      <label className="text-[11px] font-mono-code text-zinc-700 dark:text-zinc-400 font-bold block mb-1.5">
                        {t.emailLabel}
                      </label>
                      <input
                        type="email"
                        required
                        placeholder="partner@company.com"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-50 dark:bg-white/[0.03] border border-zinc-300 dark:border-white/[0.08] text-xs font-mono-code text-zinc-900 dark:text-white focus:outline-none focus:border-cyan-500 transition-colors"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[11px] font-mono-code text-zinc-700 dark:text-zinc-400 font-bold block mb-1.5">
                      {t.trackLabel}
                    </label>
                    <select
                      value={formData.track}
                      onChange={(e) => setFormData({ ...formData, track: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-50 dark:bg-white/[0.03] border border-zinc-300 dark:border-white/[0.08] text-xs font-mono-code text-zinc-900 dark:text-white focus:outline-none focus:border-cyan-500 transition-colors"
                    >
                      <option value={t.optDesign} className="bg-white dark:bg-zinc-900 text-zinc-900 dark:text-white">{t.optDesign}</option>
                      <option value={t.optDev} className="bg-white dark:bg-zinc-900 text-zinc-900 dark:text-white">{t.optDev}</option>
                      <option value={t.optSec} className="bg-white dark:bg-zinc-900 text-zinc-900 dark:text-white">{t.optSec}</option>
                      <option value={t.optRole} className="bg-white dark:bg-zinc-900 text-zinc-900 dark:text-white">{t.optRole}</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-[11px] font-mono-code text-zinc-700 dark:text-zinc-400 font-bold block mb-1.5">
                      {t.msgLabel}
                    </label>
                    <textarea
                      required
                      rows={4}
                      placeholder="Jelaskan kebutuhan proyek, kolaborasi desain, atau audit keamanan..."
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-zinc-50 dark:bg-white/[0.03] border border-zinc-300 dark:border-white/[0.08] text-xs font-mono-code text-zinc-900 dark:text-white focus:outline-none focus:border-cyan-500 transition-colors resize-none"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full inline-flex items-center justify-center gap-2 py-3 rounded-2xl bg-zinc-950 text-white dark:bg-white dark:text-black font-bold text-xs font-mono-code hover:bg-cyan-600 dark:hover:bg-cyan-400 hover:text-white dark:hover:text-black transition-all shadow-md hover:shadow-lg"
                  >
                    <span>{t.submitBtn}</span>
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
