'use client';

import React from 'react';
import { motion } from 'framer-motion';
import { BookOpen, ExternalLink, CheckCircle2, ArrowRight } from 'lucide-react';
import { PORTFOLIO_DATA } from '@/data/portfolio-data';
import { useApp } from '@/context/AppContext';
import { DICTIONARY } from '@/data/translations';

export default function Publications() {
  const { publications } = PORTFOLIO_DATA;
  const { language } = useApp();
  const t = DICTIONARY[language].publications;

  return (
    <section id="publications" className="py-20 md:py-28 relative border-t border-black/10 dark:border-white/[0.08]">
      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-12 gap-6 pb-4 border-b border-black/10 dark:border-white/[0.06]">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="p-1 rounded bg-blue-500/10 text-blue-500 dark:text-blue-400 border border-blue-500/30">
                <BookOpen className="w-3.5 h-3.5" />
              </span>
              <span className="text-xs font-mono-code uppercase tracking-[0.25em] text-blue-700 dark:text-blue-400 font-bold">
                {t.eyebrow}
              </span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-editorial font-extrabold tracking-tight text-zinc-950 dark:text-white">
              {t.title}
            </h2>
          </div>

          <div className="text-xs font-mono-code text-zinc-600 dark:text-zinc-400 font-semibold">
            INDEXED SCIENTIFIC PAPERS (DOI VERIFIED)
          </div>
        </div>

        {/* Publications Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {publications.map((pub, idx) => {
            const isForensic = pub.category.includes('FORENSICS');
            const translatedTitle = idx === 0 ? t.paper1Title : t.paper2Title;
            const translatedDesc = idx === 0 ? t.paper1Desc : t.paper2Desc;
            const translatedBadge = idx === 0 ? t.paper1Badge : t.paper2Badge;

            return (
              <motion.div
                key={pub.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                className="rounded-3xl cyber-card p-6 sm:p-8 flex flex-col justify-between hover:border-cyan-500 transition-all shadow-md dark:shadow-xl group"
              >
                <div>
                  {/* Top Meta Chips */}
                  <div className="flex items-center justify-between gap-2 mb-4">
                    <span
                      className={`px-3 py-1 text-[11px] font-mono-code font-bold rounded-full border ${
                        isForensic
                          ? 'bg-emerald-100/90 text-emerald-800 dark:bg-emerald-500/10 dark:text-emerald-300 border-emerald-300 dark:border-emerald-500/30'
                          : 'bg-cyan-100/90 text-cyan-800 dark:bg-cyan-500/10 dark:text-cyan-300 border-cyan-300 dark:border-cyan-500/30'
                      }`}
                    >
                      {translatedBadge}
                    </span>
                    <span className="text-xs font-mono-code text-zinc-500 font-semibold">
                      {pub.year}
                    </span>
                  </div>

                  {/* Title */}
                  <h3 className="text-lg sm:text-xl font-editorial font-bold mb-3 text-zinc-950 dark:text-white group-hover:text-cyan-700 dark:group-hover:text-cyan-200 transition-colors leading-snug">
                    {translatedTitle}
                  </h3>

                  {/* Journal Name & Volume */}
                  <div className="mb-4 p-3.5 rounded-2xl bg-zinc-50 dark:bg-white/[0.02] border border-zinc-200 dark:border-white/[0.05] text-xs font-mono-code flex items-center justify-between">
                    <span className="font-bold text-zinc-900 dark:text-zinc-100">📖 {pub.journal}</span>
                    <span className="text-zinc-600 dark:text-zinc-400 font-medium text-[11px]">{pub.volume}</span>
                  </div>

                  <p className="text-xs text-zinc-600 dark:text-zinc-300 font-normal leading-relaxed mb-4">
                    {translatedDesc}
                  </p>

                  {/* Key Takeaways */}
                  <div className="space-y-1.5 mb-6">
                    {pub.keyFindings.map((finding, fIdx) => (
                      <div key={fIdx} className="text-xs text-zinc-700 dark:text-zinc-300 flex items-start gap-2">
                        <CheckCircle2
                          className={`w-3.5 h-3.5 mt-0.5 shrink-0 ${
                            isForensic ? 'text-emerald-600 dark:text-emerald-400' : 'text-cyan-600 dark:text-cyan-400'
                          }`}
                        />
                        <span className="font-normal">{finding}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Bottom DOI CTA */}
                <div className="pt-4 border-t border-zinc-200 dark:border-white/[0.08] flex items-center justify-between">
                  <a
                    href={pub.doiUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-zinc-100 dark:bg-white/[0.04] border border-zinc-300 dark:border-transparent hover:bg-zinc-950 hover:text-white dark:hover:bg-cyan-400 dark:hover:text-black font-mono-code text-xs font-bold text-zinc-900 dark:text-zinc-200 transition-colors shadow-xs"
                  >
                    <span>{t.viewDoi}</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                  <span className="text-[11px] font-mono-code text-zinc-500 font-medium">{pub.doi}</span>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
