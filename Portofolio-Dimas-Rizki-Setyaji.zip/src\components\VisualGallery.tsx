'use client';

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Image from 'next/image';
import {
  X,
  Camera,
  Maximize2
} from 'lucide-react';
import { PORTFOLIO_DATA, GalleryItem } from '@/data/portfolio-data';
import ToolIcon from '@/components/ToolIcon';
import { useApp } from '@/context/AppContext';
import { DICTIONARY } from '@/data/translations';

export default function VisualGallery() {
  const { gallery } = PORTFOLIO_DATA;
  const [activeFilter, setActiveFilter] = useState<'ALL' | 'UI/UX' | 'SOCIAL' | 'PRINT'>('ALL');
  const [selectedImage, setSelectedImage] = useState<GalleryItem | null>(null);
  const { language } = useApp();
  const t = DICTIONARY[language].gallery;

  const filteredItems =
    activeFilter === 'ALL'
      ? gallery
      : gallery.filter((item) => item.category === activeFilter);

  const filterTabs = [
    { key: 'ALL', label: t.filterAll },
    { key: 'SOCIAL', label: t.filterSocial },
    { key: 'UI/UX', label: t.filterBrand },
    { key: 'PRINT', label: t.filterPrint },
  ] as const;

  return (
    <section id="gallery" className="py-20 md:py-28 relative border-t border-zinc-200 dark:border-white/[0.08]">
      {/* Background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[500px] bg-gradient-to-r from-cyan-500/5 via-blue-500/5 to-transparent blur-[160px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6 pb-4 border-b border-zinc-200 dark:border-white/[0.06]">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="h-2 w-2 rounded-full bg-cyan-500 animate-pulse" />
              <span className="text-xs font-mono-code uppercase tracking-[0.25em] text-cyan-700 dark:text-cyan-400 font-bold">
                {t.eyebrow}
              </span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-editorial font-extrabold tracking-tight text-zinc-950 dark:text-white">
              {t.title}
            </h2>
          </div>

          {/* Interactive Filter Pills */}
          <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-zinc-100 dark:bg-white/[0.03] border border-zinc-300 dark:border-white/[0.08] rounded-2xl backdrop-blur-md shadow-xs">
            {filterTabs.map((tab) => (
              <button
                key={tab.key}
                onClick={() => setActiveFilter(tab.key)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-mono-code transition-all ${
                  activeFilter === tab.key
                    ? 'bg-zinc-950 text-white dark:bg-white dark:text-black font-bold shadow-md'
                    : 'text-zinc-600 dark:text-zinc-400 hover:text-zinc-950 dark:hover:text-white hover:bg-zinc-200/60 dark:hover:bg-white/[0.05] font-semibold'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Masonry / Responsive Visual Showcase Grid */}
        <motion.div
          layout
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {filteredItems.map((item, idx) => (
            <motion.div
              layout
              key={item.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.4, delay: idx * 0.05 }}
              onClick={() => setSelectedImage(item)}
              className="group relative rounded-3xl cyber-card overflow-hidden cursor-pointer hover:border-cyan-400/50 hover:shadow-[0_15px_40px_rgba(0,242,254,0.15)] transition-all duration-500 flex flex-col shadow-sm"
            >
              {/* Image Container with Aspect Ratio */}
              <div
                className={`relative w-full overflow-hidden bg-zinc-100 dark:bg-black/60 ${
                  item.aspect === 'portrait'
                    ? 'aspect-[3/4]'
                    : item.aspect === 'wide'
                    ? 'aspect-[16/9]'
                    : 'aspect-square'
                }`}
              >
                <Image
                  src={item.image}
                  alt={item.title}
                  fill
                  sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                  className="object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out"
                />

                {/* Dark Gradient Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-60 group-hover:opacity-40 transition-opacity" />

                {/* Top Category Badge */}
                <div className="absolute top-4 left-4 z-10">
                  <span className="px-2.5 py-1 text-[10px] font-mono-code font-bold rounded-full bg-black/80 border border-white/20 text-cyan-300 backdrop-blur-md">
                    {item.categoryLabel}
                  </span>
                </div>

                {/* Hover Inspect Icon */}
                <div className="absolute top-4 right-4 z-10 w-8 h-8 rounded-full bg-black/70 border border-white/20 flex items-center justify-center text-white opacity-0 group-hover:opacity-100 transition-opacity backdrop-blur-md">
                  <Maximize2 className="w-3.5 h-3.5" />
                </div>
              </div>

              {/* Card Footer Content */}
              <div className="p-5 flex flex-col justify-between flex-1">
                <div>
                  <h3 className="text-lg font-editorial font-bold mb-1.5 text-zinc-950 dark:text-white group-hover:text-cyan-700 dark:group-hover:text-cyan-200 transition-colors">
                    {item.title}
                  </h3>
                  <p className="text-xs text-zinc-600 dark:text-zinc-400 font-normal line-clamp-2 leading-relaxed mb-3">
                    {item.caption}
                  </p>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-2 pt-3 border-t border-zinc-200 dark:border-white/[0.06]">
                  <div className="flex flex-wrap gap-1">
                    {item.tools.slice(0, 3).map((tool) => (
                      <span
                        key={tool}
                        className="px-2 py-0.5 text-[9px] font-mono-code font-medium rounded bg-zinc-100 dark:bg-white/[0.04] text-zinc-700 dark:text-zinc-400 border border-zinc-200 dark:border-white/[0.05]"
                      >
                        {tool}
                      </span>
                    ))}
                  </div>
                  {item.cameraExif && (
                    <span className="text-[10px] font-mono-code text-cyan-700 dark:text-cyan-400/90 font-semibold flex items-center gap-1">
                      <Camera className="w-3 h-3" />
                      EXIF
                    </span>
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>

      {/* Fullscreen Interactive Lightbox Modal */}
      <AnimatePresence>
        {selectedImage && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 md:p-8 bg-black/90 backdrop-blur-2xl">
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative w-full max-w-4xl max-h-[90vh] overflow-y-auto rounded-3xl bg-white dark:bg-[#090d16] text-black dark:text-white border border-black/10 dark:border-white/20 p-6 md:p-8 shadow-2xl"
            >
              {/* Close button */}
              <button
                onClick={() => setSelectedImage(null)}
                className="absolute top-5 right-5 z-20 p-2.5 rounded-full bg-black/10 dark:bg-white/[0.08] hover:bg-black/20 dark:hover:bg-white/20 text-zinc-700 dark:text-zinc-300 transition-colors"
                aria-label="Close"
              >
                <X className="w-5 h-5" />
              </button>

              {/* Large Image Preview */}
              <div className="relative w-full h-[50vh] md:h-[60vh] rounded-2xl overflow-hidden bg-black/90 mb-6 border border-black/10 dark:border-white/10">
                <Image
                  src={selectedImage.image}
                  alt={selectedImage.title}
                  fill
                  sizes="100vw"
                  className="object-contain"
                />
              </div>

              {/* Image Information */}
              <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
                <div>
                  <div className="flex items-center gap-2.5 mb-2">
                    <span className="px-3 py-1 text-xs font-mono-code rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-600 dark:text-cyan-300">
                      {selectedImage.categoryLabel}
                    </span>
                    {selectedImage.cameraExif && (
                      <span className="text-xs font-mono-code text-zinc-500">
                        {selectedImage.cameraExif}
                      </span>
                    )}
                  </div>
                  <h3 className="text-2xl md:text-3xl font-editorial font-bold mb-2">
                    {selectedImage.title}
                  </h3>
                  <p className="text-sm text-zinc-600 dark:text-zinc-300 font-light leading-relaxed max-w-2xl">
                    {selectedImage.caption}
                  </p>
                </div>

                {/* Tools Applied */}
                <div className="flex flex-col gap-2 shrink-0">
                  <span className="text-[10px] font-mono-code text-zinc-500 uppercase tracking-widest">
                    {t.toolsApplied}
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedImage.tools.map((toolName) => (
                      <span
                        key={toolName}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 text-xs font-mono-code rounded-lg bg-black/[0.04] dark:bg-white/[0.04] border border-black/10 dark:border-white/10"
                      >
                        <ToolIcon name={toolName} className="w-3.5 h-3.5 shrink-0" />
                        <span>{toolName}</span>
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
