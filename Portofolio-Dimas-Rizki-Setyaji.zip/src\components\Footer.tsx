'use client';

import React from 'react';
import Link from 'next/link';
import { ArrowUp } from 'lucide-react';
import { PORTFOLIO_DATA } from '@/data/portfolio-data';
import { useApp } from '@/context/AppContext';
import { DICTIONARY } from '@/data/translations';

export default function Footer() {
  const { profile } = PORTFOLIO_DATA;
  const { language } = useApp();
  const t = DICTIONARY[language].footer;

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="py-12 border-t border-zinc-200 dark:border-white/[0.08] relative">
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex flex-col sm:flex-row items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="font-editorial font-bold text-base text-zinc-950 dark:text-white">
              {profile.name}
            </span>
            <span className="text-xs font-mono-code text-zinc-500 font-semibold">
              © {new Date().getFullYear()}
            </span>
          </div>
          <p className="text-xs font-mono-code text-zinc-600 dark:text-zinc-400 font-medium">
            {t.builtWith}
          </p>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono-code">
          <Link href="/design" className="text-zinc-600 dark:text-zinc-400 hover:text-cyan-700 dark:hover:text-cyan-400 font-semibold transition-colors">
            {t.designLab}
          </Link>
          <Link href="/security" className="text-zinc-600 dark:text-zinc-400 hover:text-emerald-700 dark:hover:text-emerald-400 font-semibold transition-colors">
            {t.securityLab}
          </Link>
          <Link href="/security#publications" className="text-zinc-600 dark:text-zinc-400 hover:text-blue-700 dark:hover:text-blue-400 font-semibold transition-colors">
            {t.publications}
          </Link>
          <button
            onClick={scrollToTop}
            className="p-2 rounded-xl bg-zinc-100 dark:bg-white/[0.04] border border-zinc-300 dark:border-transparent hover:bg-zinc-950 hover:text-white dark:hover:bg-cyan-400 dark:hover:text-black transition-colors"
            title="Back to Top"
          >
            <ArrowUp className="w-4 h-4" />
          </button>
        </div>
      </div>
    </footer>
  );
}
