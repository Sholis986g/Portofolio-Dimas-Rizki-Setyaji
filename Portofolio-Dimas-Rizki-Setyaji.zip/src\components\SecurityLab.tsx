'use client';

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import {
  ShieldCheck,
  Search,
  Play,
  Copy,
  Check
} from 'lucide-react';
import { PORTFOLIO_DATA } from '@/data/portfolio-data';
import { useApp } from '@/context/AppContext';

export default function SecurityLab() {
  const { securityLab } = PORTFOLIO_DATA;
  const { language } = useApp();
  const [activeModuleId, setActiveModuleId] = useState<string>(securityLab.modules[0].id);
  const [terminalInput, setTerminalInput] = useState('');
  const [terminalHistory, setTerminalHistory] = useState<
    { command: string; output: string; time: string }[]
  >([
    {
      command: 'drs-sec audit --nist-sp800-86',
      output: 'NIST FORENSIC STATUS: SHA-256 VERIFIED · PERSISTENCE ISOLATED · SYSTEM NOMINAL',
      time: '12:00:01'
    }
  ]);
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);

  const activeModule =
    securityLab.modules.find((m) => m.id === activeModuleId) || securityLab.modules[0];

  const handleCommandRun = (customCmd?: string) => {
    const cmd = customCmd || terminalInput;
    if (!cmd.trim()) return;

    let response = '';
    const cleanCmd = cmd.toLowerCase().trim();

    if (cleanCmd.includes('owasp') || cleanCmd.includes('web')) {
      response = language === 'id'
        ? 'AUDIT BERHASIL: Kebijakan CSP aktif (default-src self), mitigasi XSS terverifikasi, cookie autentikasi SameSite=Strict.'
        : 'AUDIT PASS: CSP active (default-src self), XSS mitigation verified, SameSite=Strict on all auth cookies.';
    } else if (cleanCmd.includes('forensic') || cleanCmd.includes('sha256') || cleanCmd.includes('wp_options')) {
      response = language === 'id'
        ? 'HASH TERVERIFIKASI: 9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08 · Integritas barang bukti terjamin.'
        : 'HASH VERIFIED: 9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08 · Immutable custody established.';
    } else if (cleanCmd.includes('osint') || cleanCmd.includes('subfinder')) {
      response = language === 'id'
        ? 'REKON SELESAI: 0 subdomain bocor · 0 secret key terekspos · Kebijakan DMARC p=reject terverifikasi.'
        : 'RECON COMPLETE: 0 exposed subdomains · 0 leaked secrets · DMARC p=reject verified.';
    } else if (cleanCmd.includes('network') || cleanCmd.includes('pcap') || cleanCmd.includes('docker')) {
      response = language === 'id'
        ? 'INSPEKSI PAKET: 0 aliran data tidak terenkripsi · Lalu lintas keluar (egress) terkunci ke endpoint terotorisasi.'
        : 'PACKET INSPECTION: 0 unencrypted cleartext streams · Egress strictly locked to authorized endpoints.';
    } else if (cleanCmd === 'help') {
      response = language === 'id'
        ? 'Perintah tersedia: audit, osint, forensics, owasp, network, status, clear'
        : 'Available commands: audit, osint, forensics, owasp, network, status, clear';
    } else if (cleanCmd === 'clear') {
      setTerminalHistory([]);
      setTerminalInput('');
      return;
    } else {
      response = language === 'id'
        ? `Perintah '${cmd}' dievaluasi pada modul pertahanan. Status aman & nominal.`
        : `Command '${cmd}' evaluated across defensive heuristics engine. Safe & nominal.`;
    }

    const now = new Date().toTimeString().split(' ')[0];
    setTerminalHistory((prev) => [
      ...prev,
      { command: cmd, output: response, time: now }
    ]);
    setTerminalInput('');
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCmd(text);
    setTimeout(() => setCopiedCmd(null), 2000);
  };

  return (
    <section id="security" className="py-20 md:py-28 relative border-t border-black/10 dark:border-white/[0.08]">
      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6 pb-4 border-b border-zinc-200 dark:border-white/[0.06]">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="h-2 w-2 rounded-full bg-cyan-500 animate-pulse" />
              <span className="text-xs font-mono-code uppercase tracking-[0.25em] text-cyan-700 dark:text-cyan-400 font-bold">
                05 / SECURITY RESEARCH & CSIRT LAB
              </span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-editorial font-extrabold tracking-tight text-zinc-950 dark:text-white">
              {language === 'id' ? 'LAB RISET KEAMANAN' : 'SECURITY RESEARCH LAB'}
            </h2>
          </div>
          <div className="max-w-md">
            <p className="text-xs font-mono-code text-zinc-600 dark:text-zinc-400 font-medium leading-relaxed border-l-2 border-cyan-500 pl-3">
              {securityLab.subtitle}
            </p>
          </div>
        </div>

        {/* Top Telemetry Bar */}
        <div className="mb-8 p-3.5 rounded-2xl bg-zinc-50 dark:bg-black/60 border border-zinc-200 dark:border-white/[0.08] backdrop-blur-xl flex flex-wrap items-center justify-between gap-4 text-xs font-mono-code shadow-xs">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 px-2.5 py-1 rounded-md bg-emerald-100/90 border border-emerald-300 dark:bg-emerald-500/10 dark:border-emerald-500/30 text-emerald-800 dark:text-emerald-400 font-bold">
              <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>{language === 'id' ? 'STATUS: CSIRT ANALIS AKTIF' : 'DEFENSIVE ENGINE: CSIRT ACTIVE'}</span>
            </div>
            <span className="text-zinc-300 dark:text-zinc-600 hidden sm:inline">|</span>
            <span className="text-zinc-600 dark:text-zinc-400 font-medium hidden sm:inline">STANDARDS: NIST SP 800-86 · OWASP</span>
          </div>

          <div className="flex items-center gap-4 text-zinc-600 dark:text-zinc-400 text-[11px] font-semibold">
            <span>HASH: SHA-256</span>
            <span className="text-cyan-700 dark:text-cyan-400">ISOLATION: DOCKER BRIDGE</span>
          </div>
        </div>

        {/* Main Research Sandbox Dashboard */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left Column: Category Selectors */}
          <div className="lg:col-span-4 flex flex-col gap-3">
            <div className="text-xs font-mono-code text-zinc-600 dark:text-zinc-400 font-bold uppercase tracking-widest mb-1 px-1">
              {language === 'id' ? 'DOMAIN KEAMANAN' : 'SECURITY DOMAINS'}
            </div>

            {securityLab.modules.map((module) => {
              const isActive = activeModuleId === module.id;
              return (
                <button
                  key={module.id}
                  onClick={() => setActiveModuleId(module.id)}
                  className={`text-left p-4 rounded-2xl border transition-all duration-300 relative shadow-xs ${
                    isActive
                      ? 'bg-zinc-100 dark:bg-[#0f1424] border-cyan-500/60 shadow-[0_0_25px_rgba(2,132,199,0.15)]'
                      : 'bg-zinc-50 dark:bg-white/[0.02] border-zinc-200 dark:border-white/[0.06] hover:bg-zinc-100 dark:hover:bg-white/[0.05]'
                  }`}
                >
                  {isActive && (
                    <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-8 bg-cyan-600 dark:bg-cyan-400 rounded-r" />
                  )}
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] font-mono-code text-cyan-700 dark:text-cyan-400 font-bold tracking-wider">
                      {module.category}
                    </span>
                    <span
                      className={`text-[9px] font-mono-code px-2 py-0.5 rounded font-bold ${
                        module.status === 'HARDENED'
                          ? 'bg-emerald-100/90 text-emerald-800 border border-emerald-300 dark:bg-emerald-500/10 dark:text-emerald-300 dark:border-emerald-500/30'
                          : module.status === 'VERIFIED'
                          ? 'bg-blue-100/90 text-blue-800 border border-blue-300 dark:bg-blue-500/10 dark:text-blue-300 dark:border-blue-500/30'
                          : 'bg-amber-100/90 text-amber-800 border border-amber-300 dark:bg-amber-500/10 dark:text-amber-300 dark:border-amber-500/30'
                      }`}
                    >
                      {module.status}
                    </span>
                  </div>
                  <h4 className="text-base font-editorial font-bold mb-0.5 text-zinc-950 dark:text-white">
                    {module.title}
                  </h4>
                  <p className="text-xs text-zinc-600 dark:text-zinc-400 line-clamp-1 font-normal">
                    {module.summary}
                  </p>
                </button>
              );
            })}
          </div>

          {/* Right Column: Detailed Security Analysis & Micro-Terminal */}
          <div className="lg:col-span-8 flex flex-col gap-6">
            {/* Analysis Card */}
            <motion.div
              key={activeModule.id}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
              className="p-6 md:p-8 rounded-3xl cyber-card shadow-sm"
            >
              {/* Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-6 border-b border-zinc-200 dark:border-white/[0.08]">
                <div>
                  <div className="text-xs font-mono-code text-cyan-700 dark:text-cyan-400 font-bold mb-1">
                    {activeModule.cveOrStandard}
                  </div>
                  <h3 className="text-xl sm:text-2xl font-editorial font-bold text-zinc-950 dark:text-white">
                    {activeModule.title}
                  </h3>
                </div>
                <button
                  onClick={() => handleCommandRun(activeModule.commandSample)}
                  className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-cyan-100/90 border border-cyan-300 text-cyan-800 dark:bg-cyan-500/10 dark:border-cyan-500/30 dark:text-cyan-300 hover:bg-cyan-600 hover:text-white text-xs font-mono-code font-bold self-start sm:self-auto transition-colors shadow-xs"
                >
                  <Play className="w-3 h-3" />
                  <span>{language === 'id' ? 'JALANKAN UJI' : 'RUN TEST'}</span>
                </button>
              </div>

              {/* Visual Execution Pipeline */}
              {activeModule.attackChainDiagram && (
                <div className="mb-6 p-4 rounded-2xl bg-zinc-50 dark:bg-black/40 border border-zinc-200 dark:border-white/[0.06]">
                  <span className="text-[10px] font-mono-code text-zinc-600 dark:text-zinc-400 font-bold uppercase tracking-widest block mb-3">
                    {language === 'id' ? 'PIPELINE EKSEKUSI VISUAL' : 'VISUAL EXECUTION PIPELINE'}
                  </span>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {activeModule.attackChainDiagram.map((step, sIdx) => (
                      <div
                        key={sIdx}
                        className="p-2.5 rounded-xl bg-white dark:bg-white/[0.03] border border-zinc-200 dark:border-white/[0.06] flex flex-col justify-between shadow-xs"
                      >
                        <div className="flex items-center justify-between text-[10px] font-mono-code text-cyan-700 dark:text-cyan-400 font-bold mb-1">
                          <span>STEP {step.step}</span>
                        </div>
                        <div className="text-xs font-editorial font-bold text-zinc-950 dark:text-white">
                          {step.label}
                        </div>
                        <div className="text-[10px] font-mono-code text-zinc-500 truncate mt-0.5 font-medium">
                          {step.desc}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Findings & Mitigations Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                {/* Findings */}
                <div className="p-4 rounded-2xl bg-zinc-50 dark:bg-white/[0.02] border border-zinc-200 dark:border-white/[0.06]">
                  <div className="flex items-center gap-2 text-xs font-mono-code font-bold mb-2.5 text-zinc-900 dark:text-white">
                    <Search className="w-3.5 h-3.5 text-cyan-600 dark:text-cyan-400" />
                    <span>{language === 'id' ? 'TEMUAN INSIDEN' : 'SURFACE FINDINGS'}</span>
                  </div>
                  <div className="space-y-1.5">
                    {activeModule.findings.map((f, fIdx) => (
                      <div key={fIdx} className="text-xs text-zinc-700 dark:text-zinc-400 flex items-start gap-2">
                        <span className="w-1 h-1 rounded-full bg-cyan-600 dark:bg-cyan-400 mt-1.5 shrink-0" />
                        <span>{f}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Mitigations */}
                <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-500/[0.03] border border-emerald-200 dark:border-emerald-500/15">
                  <div className="flex items-center gap-2 text-xs font-mono-code text-emerald-800 dark:text-emerald-400 font-bold mb-2.5">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                    <span>{language === 'id' ? 'ATURAN REMEDIASI' : 'MITIGATION RULES'}</span>
                  </div>
                  <div className="space-y-1.5">
                    {activeModule.mitigations.map((m, mIdx) => (
                      <div key={mIdx} className="text-xs text-emerald-900 dark:text-emerald-200/90 font-medium flex items-start gap-2">
                        <span className="w-1 h-1 rounded-full bg-emerald-600 dark:bg-emerald-400 mt-1.5 shrink-0" />
                        <span>{m}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Command Sample */}
              {activeModule.commandSample && (
                <div className="p-3 rounded-xl bg-zinc-100 dark:bg-black/60 border border-zinc-300 dark:border-white/[0.08] flex items-center justify-between gap-3 font-mono-code text-xs shadow-xs">
                  <div className="flex items-center gap-2 text-zinc-800 dark:text-zinc-300 overflow-x-auto text-[11px] font-medium">
                    <span className="text-cyan-700 dark:text-cyan-400 select-none font-bold">$</span>
                    <span>{activeModule.commandSample}</span>
                  </div>
                  <button
                    onClick={() => copyToClipboard(activeModule.commandSample!)}
                    className="p-1 text-zinc-600 hover:text-black dark:text-zinc-400 dark:hover:text-white transition-colors"
                    title="Copy command"
                  >
                    {copiedCmd === activeModule.commandSample ? (
                      <Check className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-500" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              )}
            </motion.div>

            {/* Interactive Defensive Micro-Terminal */}
            <div className="rounded-3xl bg-[#04060c] text-white border border-white/10 p-5 shadow-2xl font-mono-code">
              {/* Terminal Window Header */}
              <div className="flex items-center justify-between pb-2.5 mb-3 border-b border-white/[0.08] text-xs text-zinc-400">
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-red-500/80" />
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
                  </div>
                  <span className="text-zinc-500 text-[10px] ml-2">dimas@bptsi-csirt: ~</span>
                </div>
                <div className="text-[10px] text-zinc-500">INTERACTIVE SECURITY CLI</div>
              </div>

              {/* Terminal Logs Output */}
              <div className="space-y-2 max-h-36 overflow-y-auto pr-2 text-xs">
                {terminalHistory.map((item, idx) => (
                  <div key={idx} className="space-y-0.5">
                    <div className="flex items-center gap-2 text-cyan-300 text-[11px]">
                      <span className="text-zinc-500 text-[9px]">[{item.time}]</span>
                      <span className="text-white">$ {item.command}</span>
                    </div>
                    <div className="text-zinc-400 pl-3 border-l border-white/10 text-[10px] leading-relaxed">
                      {item.output}
                    </div>
                  </div>
                ))}
              </div>

              {/* Terminal Interactive Input */}
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleCommandRun();
                }}
                className="mt-3 pt-2.5 border-t border-white/[0.08] flex items-center gap-2 text-xs"
              >
                <span className="text-cyan-400 font-bold">$</span>
                <input
                  type="text"
                  value={terminalInput}
                  onChange={(e) => setTerminalInput(e.target.value)}
                  placeholder="Type command (audit, osint, forensics, clear, help)..."
                  className="flex-1 bg-transparent border-none text-white focus:outline-none placeholder:text-zinc-600 text-xs"
                />
                <button
                  type="submit"
                  className="px-2.5 py-0.5 bg-white/[0.08] hover:bg-white/[0.15] text-zinc-200 rounded text-[10px] transition-colors"
                >
                  EXEC
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
