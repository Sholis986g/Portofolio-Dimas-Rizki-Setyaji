'use client';

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Palette, Code2, ShieldAlert, Sparkles, Check, ArrowRight, Layers } from 'lucide-react';
import { PORTFOLIO_DATA } from '@/data/portfolio-data';

export default function Expertise() {
  const { expertise } = PORTFOLIO_DATA;
  const [hoveredCard, setHoveredCard] = useState<string | null>(null);

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Palette':
        return <Palette className="w-6 h-6 text-cyan-400" />;
      case 'Code2':
        return <Code2 className="w-6 h-6 text-blue-400" />;
      case 'ShieldAlert':
        return <ShieldAlert className="w-6 h-6 text-emerald-400" />;
      default:
        return <Sparkles className="w-6 h-6 text-cyan-400" />;
    }
  };

  return (
    <section id="expertise" className="py-24 md:py-32 relative border-t border-white/[0.06] bg-[#050816]/40">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="h-1.5 w-1.5 rounded-full bg-cyan-400" />
              <span className="text-xs font-mono-code uppercase tracking-[0.25em] text-zinc-400">
                02 / CORE CAPABILITIES
              </span>
            </div>
            <h2 className="text-4xl md:text-6xl font-editorial font-extrabold tracking-tight text-white">
              TRIAD OF EXPERTISE
            </h2>
          </div>
          <p className="text-sm font-mono-code text-zinc-400 max-w-sm">
            THREE INTERCONNECTED DOMAINS. ZERO SILOS. CRAFTED FOR MODERN DIGITAL PRODUCTS.
          </p>
        </div>

        {/* 3 Large Interactive Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {expertise.map((card, idx) => {
            const isHovered = hoveredCard === card.id;

            return (
              <motion.div
                key={card.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.7, delay: idx * 0.15 }}
                onMouseEnter={() => setHoveredCard(card.id)}
                onMouseLeave={() => setHoveredCard(null)}
                className={`group relative flex flex-col justify-between rounded-3xl p-8 md:p-10 bg-gradient-to-b from-[#0e121d]/80 to-[#080b12]/90 border border-white/[0.08] backdrop-blur-xl transition-all duration-500 hover:scale-[1.01] hover:border-white/20 hover:shadow-[0_20px_50px_rgba(0,0,0,0.8)]`}
              >
                {/* Subtle top atmospheric glow on hover */}
                <div
                  className={`absolute top-0 left-0 right-0 h-40 bg-gradient-to-b ${card.accent} rounded-t-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none`}
                />

                {/* Top Section: Pillar Tag & Icon */}
                <div>
                  <div className="flex items-center justify-between mb-8">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-2xl bg-white/[0.04] border border-white/10 flex items-center justify-center group-hover:border-cyan-400/50 group-hover:bg-cyan-400/5 transition-all">
                        {getIcon(card.icon)}
                      </div>
                      <div>
                        <span className="text-[10px] font-mono-code tracking-[0.25em] text-zinc-500 block">
                          MODULE {idx + 1}
                        </span>
                        <span className="text-sm font-editorial font-bold text-white tracking-widest uppercase">
                          {card.pillar}
                        </span>
                      </div>
                    </div>

                    <span className="text-2xl font-editorial font-bold text-zinc-700 group-hover:text-zinc-400 transition-colors">
                      0{idx + 1}
                    </span>
                  </div>

                  {/* Headline & Tagline */}
                  <h3 className="text-2xl md:text-3xl font-editorial font-bold text-white mb-2 group-hover:text-cyan-200 transition-colors">
                    {card.headline}
                  </h3>
                  <div className="text-xs font-mono-code text-cyan-400/90 mb-6 tracking-wide">
                    {card.tagline}
                  </div>

                  {/* Description */}
                  <p className="text-sm text-zinc-300 font-light leading-relaxed mb-8">
                    {card.description}
                  </p>

                  {/* Disciplines / Deliverables */}
                  <div className="mb-8 space-y-2">
                    <div className="text-[11px] font-mono-code text-zinc-400 uppercase tracking-wider mb-2.5">
                      KEY DELIVERABLES:
                    </div>
                    {card.disciplines.map((item, dIdx) => (
                      <div key={dIdx} className="flex items-center gap-2 text-xs text-zinc-300">
                        <span className="w-1.5 h-1.5 rounded-full bg-cyan-400/70" />
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Bottom Section: Skills Badges */}
                <div className="pt-6 border-t border-white/[0.08]">
                  <div className="text-[10px] font-mono-code text-zinc-400 uppercase tracking-widest mb-3">
                    CORE TOOLING & SKILLS
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {card.skills.map((skill) => (
                      <span
                        key={skill}
                        className="px-2.5 py-1 text-[11px] font-mono-code rounded-md bg-white/[0.03] border border-white/[0.06] text-zinc-300 group-hover:border-white/15 transition-colors"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
