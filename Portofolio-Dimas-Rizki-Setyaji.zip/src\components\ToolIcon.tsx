'use client';

import React from 'react';
import Image from 'next/image';

interface ToolIconProps {
  name: string;
  className?: string;
}

export default function ToolIcon({ name, className = 'w-5 h-5' }: ToolIconProps) {
  const normalized = name.toLowerCase().trim();

  // Adobe Photoshop
  if (normalized.includes('photoshop') || normalized === 'ps') {
    return (
      <span className={`relative inline-flex items-center justify-center ${className} shrink-0`}>
        <Image
          src="/icons/photoshop.svg"
          alt="Adobe Photoshop"
          width={24}
          height={24}
          className="w-full h-full object-contain"
        />
      </span>
    );
  }

  // Adobe Illustrator
  if (normalized.includes('illustrator') || normalized === 'ai') {
    return (
      <span className={`relative inline-flex items-center justify-center ${className} shrink-0`}>
        <Image
          src="/icons/illustrator.svg"
          alt="Adobe Illustrator"
          width={24}
          height={24}
          className="w-full h-full object-contain"
        />
      </span>
    );
  }

  // Adobe Lightroom
  if (normalized.includes('lightroom') || normalized === 'lr') {
    return (
      <span className={`relative inline-flex items-center justify-center ${className} shrink-0`}>
        <Image
          src="/icons/lightroom.svg"
          alt="Adobe Lightroom"
          width={24}
          height={24}
          className="w-full h-full object-contain"
        />
      </span>
    );
  }

  // Figma
  if (normalized.includes('figma')) {
    return (
      <span className={`relative inline-flex items-center justify-center ${className} shrink-0`}>
        <Image
          src="/icons/figma.svg"
          alt="Figma"
          width={24}
          height={24}
          className="w-full h-full object-contain"
        />
      </span>
    );
  }

  // Canva Pro
  if (normalized.includes('canva')) {
    return (
      <span className={`relative inline-flex items-center justify-center ${className} shrink-0`}>
        <Image
          src="/icons/canva.svg"
          alt="Canva"
          width={24}
          height={24}
          className="w-full h-full object-contain rounded-md"
        />
      </span>
    );
  }

  // Docker
  if (normalized.includes('docker')) {
    return (
      <span className={`relative inline-flex items-center justify-center ${className} shrink-0`}>
        <Image
          src="/icons/docker.svg"
          alt="Docker"
          width={24}
          height={24}
          className="w-full h-full object-contain"
        />
      </span>
    );
  }

  // PHP
  if (normalized.includes('php')) {
    return (
      <span className={`relative inline-flex items-center justify-center ${className} shrink-0`}>
        <Image
          src="/icons/php.svg"
          alt="PHP"
          width={24}
          height={24}
          className="w-full h-full object-contain"
        />
      </span>
    );
  }

  // Laravel
  if (normalized.includes('laravel')) {
    return (
      <span className={`relative inline-flex items-center justify-center ${className} shrink-0`}>
        <Image
          src="/icons/laravel.svg"
          alt="Laravel"
          width={24}
          height={24}
          className="w-full h-full object-contain"
        />
      </span>
    );
  }

  // WordPress
  if (normalized.includes('wordpress') || normalized === 'wp') {
    return (
      <span className={`relative inline-flex items-center justify-center ${className} shrink-0`}>
        <Image
          src="/icons/wordpress.svg"
          alt="WordPress"
          width={24}
          height={24}
          className="w-full h-full object-contain"
        />
      </span>
    );
  }

  // JavaScript
  if (normalized.includes('javascript') || normalized.includes('js')) {
    return (
      <span className={`relative inline-flex items-center justify-center ${className} shrink-0`}>
        <Image
          src="/icons/javascript.svg"
          alt="JavaScript"
          width={24}
          height={24}
          className="w-full h-full object-contain"
        />
      </span>
    );
  }

  // TypeScript
  if (normalized.includes('typescript') || normalized.includes('ts')) {
    return (
      <span className={`relative inline-flex items-center justify-center ${className} shrink-0`}>
        <Image
          src="/icons/typescript.svg"
          alt="TypeScript"
          width={24}
          height={24}
          className="w-full h-full object-contain"
        />
      </span>
    );
  }

  // MySQL Database
  if (normalized.includes('mysql') || normalized.includes('database') || normalized.includes('sql')) {
    return (
      <span className={`relative inline-flex items-center justify-center ${className} shrink-0`}>
        <Image
          src="/icons/mysql.svg"
          alt="MySQL"
          width={24}
          height={24}
          className="w-full h-full object-contain"
        />
      </span>
    );
  }

  // Linux
  if (normalized.includes('linux') || normalized.includes('ubuntu')) {
    return (
      <span className={`relative inline-flex items-center justify-center ${className} shrink-0`}>
        <Image
          src="/icons/linux.svg"
          alt="Linux"
          width={24}
          height={24}
          className="w-full h-full object-contain"
        />
      </span>
    );
  }

  // Nginx
  if (normalized.includes('nginx')) {
    return (
      <span className={`relative inline-flex items-center justify-center ${className} shrink-0`}>
        <Image
          src="/icons/nginx.svg"
          alt="Nginx"
          width={24}
          height={24}
          className="w-full h-full object-contain"
        />
      </span>
    );
  }

  // OWASP
  if (normalized.includes('owasp')) {
    return (
      <span className={`relative inline-flex items-center justify-center ${className} shrink-0 bg-blue-950/60 p-0.5 rounded-lg border border-blue-500/30`}>
        <Image
          src="/icons/owasp.svg"
          alt="OWASP"
          width={24}
          height={24}
          className="w-full h-full object-contain invert brightness-125"
        />
      </span>
    );
  }

  // Kali Linux / Network Tools
  if (normalized.includes('kali') || normalized.includes('wireshark')) {
    return (
      <span className={`relative inline-flex items-center justify-center ${className} shrink-0`}>
        <Image
          src="/icons/wireshark.svg"
          alt="Network Security"
          width={24}
          height={24}
          className="w-full h-full object-contain"
        />
      </span>
    );
  }

  // NIST SP 800-86 (Digital Forensics Framework)
  if (normalized.includes('nist') || normalized.includes('800-86') || normalized.includes('forensics')) {
    return (
      <svg viewBox="0 0 256 256" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="256" height="256" rx="56" fill="#002D62" />
        <path
          d="M128 40L56 74v62c0 48 30.8 93 72 106 41.2-13 72-58 72-106V74l-72-34z"
          fill="#001833"
          stroke="#00A3E0"
          strokeWidth="8"
        />
        <rect x="98" y="98" width="60" height="60" rx="8" fill="#002D62" stroke="#00A3E0" strokeWidth="6" />
        <circle cx="128" cy="128" r="14" fill="#00A3E0" />
        <path d="M128 76v22M128 158v22M76 128h22M158 128h22" stroke="#00A3E0" strokeWidth="6" strokeLinecap="round" />
        <text x="128" y="200" textAnchor="middle" fill="#00A3E0" fontSize="18" fontWeight="bold" fontFamily="monospace">NIST</text>
      </svg>
    );
  }

  // MITRE ATT&CK
  if (normalized.includes('mitre') || normalized.includes('att&ck')) {
    return (
      <svg viewBox="0 0 256 256" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="256" height="256" rx="56" fill="#1C2833" />
        <path
          d="M128 36L48 76v60c0 50 34 97 80 110 46-13 80-60 80-110V76l-80-40z"
          fill="#E74C3C"
        />
        <path
          d="M128 54L64 86v50c0 40 27.2 77.6 64 88 36.8-10.4 64-48 64-88V86l-64-32z"
          fill="#1C2833"
        />
        <path
          d="M84 100h88M84 128h88M84 156h88M108 90v80M148 90v80"
          stroke="#E74C3C"
          strokeWidth="5"
          strokeLinecap="round"
        />
        <circle cx="128" cy="128" r="8" fill="#FF5252" />
      </svg>
    );
  }

  // CSIRT Operations
  if (normalized.includes('csirt') || normalized.includes('cert') || normalized.includes('incident')) {
    return (
      <svg viewBox="0 0 256 256" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="256" height="256" rx="56" fill="#061A0E" />
        <path
          d="M128 32l84 46v54c0 54-36.8 104.6-84 116-47.2-11.4-84-62-84-116V78l84-46z"
          fill="#0D2E1A"
          stroke="#10B981"
          strokeWidth="8"
        />
        <path
          d="M128 72v64m0 32h.02"
          stroke="#10B981"
          strokeWidth="16"
          strokeLinecap="round"
        />
        <text x="128" y="210" textAnchor="middle" fill="#10B981" fontSize="22" fontWeight="bold" fontFamily="monospace">CSIRT</text>
      </svg>
    );
  }

  // OSINT Recon
  if (normalized.includes('osint') || normalized.includes('recon')) {
    return (
      <svg viewBox="0 0 256 256" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="256" height="256" rx="56" fill="#0D1117" />
        <circle cx="128" cy="128" r="80" stroke="#00F2FE" strokeWidth="6" strokeDasharray="12 12" />
        <circle cx="128" cy="128" r="46" stroke="#00F2FE" strokeWidth="4" />
        <circle cx="128" cy="128" r="14" fill="#00F2FE" />
        <path
          d="M128 36v46M128 174v46M36 128h46M174 128h46"
          stroke="#00F2FE"
          strokeWidth="6"
          strokeLinecap="round"
        />
      </svg>
    );
  }

  // BPJS Bridging
  if (normalized.includes('bpjs') || normalized.includes('health')) {
    return (
      <svg viewBox="0 0 256 256" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="256" height="256" rx="56" fill="#006633" />
        <circle cx="128" cy="128" r="92" fill="#FFFFFF" />
        <path
          d="M128 62v132M62 128h132"
          stroke="#008040"
          strokeWidth="36"
          strokeLinecap="round"
        />
        <circle cx="128" cy="128" r="28" fill="#FFFFFF" />
        <circle cx="128" cy="128" r="16" fill="#008040" />
      </svg>
    );
  }

  // Apparel / CMYK Print
  if (normalized.includes('apparel') || normalized.includes('print') || normalized.includes('cmyk')) {
    return (
      <svg viewBox="0 0 256 256" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
        <rect width="256" height="256" rx="56" fill="#18181B" />
        <circle cx="100" cy="100" r="44" fill="#00FFFF" opacity="0.85" />
        <circle cx="156" cy="100" r="44" fill="#FF00FF" opacity="0.85" />
        <circle cx="100" cy="156" r="44" fill="#FFFF00" opacity="0.85" />
        <circle cx="156" cy="156" r="44" fill="#000000" stroke="#FFFFFF" strokeWidth="4" />
      </svg>
    );
  }

  // Default fallback badge
  return (
    <svg viewBox="0 0 256 256" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect width="256" height="256" rx="56" fill="#18181B" />
      <circle cx="128" cy="128" r="48" fill="#00F2FE" />
    </svg>
  );
}
