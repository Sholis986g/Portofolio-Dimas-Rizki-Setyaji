'use client';

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, CheckCircle2, Search, Palette, Terminal, ShieldAlert } from 'lucide-react';
import { PORTFOLIO_DATA } from '@/data/portfolio-data';

export default function Philosophy() {
  const { philosophy } = PORTFOLIO_DATA;
  const [activeStep, setActiveStep] = useState<number>(0);

  const getStepIcon = (idx: number) => {
    switch (idx) {
      case 0:
        return <Search className="w-5 h-5 text-cyan-400" />;
      case 1:
        return <Palette className="w-5 h-5 text-blue-400" />;
      case 2:
        return <Terminal className="w-5 h-5 text-indigo-400" />;
      case 3:
        return <ShieldAlert className="w-5 h-5 text-emerald-400" />;
      default:
        return <CheckCircle2 className="w-5 h-5 text-cyan-400" />;
    }
  };

  return (
    <section id="philosophy" className="py-24 md:py-32 relative border-t border-white/[0.06] bg-[#050505]">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="h-1.5 w-1.5 rounded-full bg-cyan-400" />
              <span className="text-xs font-mono-code uppercase tracking-[0.25em] text-zinc-400">
                05 / METHODOLOGY
              </span>
            </div>
            <h2 className="text-4xl md:text-6xl font-editorial font-extrabold tracking-tight text-white">
              HOW I THINK
            </h2>
          </div>
          <p className="text-sm font-mono-code text-zinc-400 max-w-sm">
            FOUR RIGOROUS PHASES. FROM DISCOVERY TO SECURE RESILIENCE.
          </p>
        </div>

        {/* 4 Interactive Process Stages */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {philosophy.map((item, idx) => {
            const isActive = activeStep === idx;

            return (
              <motion.div
                key={item.step}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: idx * 0.12 }}
                onClick={() => setActiveStep(idx)}
                className={`group cursor-pointer rounded-3xl p-8 flex flex-col justify-between border transition-all duration-500 relative ${
                  isActive
                    ? 'bg-gradient-to-b from-[#0f1424] to-[#080a14] border-cyan-400/50 shadow-[0_15px_40px_rgba(0,242,254,0.12)]'
                    : 'bg-white/[0.02] border-white/[0.08] hover:bg-white/[0.04] hover:border-white/20'
                }`}
              >
                <div>
                  {/* Step Header */}
                  <div className="flex items-center justify-between mb-8">
                    <span className="font-editorial text-3xl font-bold text-zinc-600 group-hover:text-zinc-400 transition-colors">
                      {item.step}
                    </span>
                    <div className="w-10 h-10 rounded-xl bg-white/[0.04] border border-white/10 flex items-center justify-center">
                      {getStepIcon(idx)}
                    </div>
                  </div>

                  {/* Step Title */}
                  <h3 className="text-2xl font-editorial font-bold text-white mb-2 group-hover:text-cyan-200 transition-colors">
                    {item.name}
                  </h3>
                  <div className="text-xs font-mono-code text-cyan-400/90 mb-4 tracking-wide">
                    {item.label}
                  </div>

                  {/* Summary */}
                  <p className="text-sm text-zinc-300 font-light leading-relaxed mb-6">
                    {item.summary}
                  </p>

                  {/* Quote */}
                  <blockquote className="text-xs italic text-zinc-400 border-l border-white/15 pl-3 mb-6 leading-relaxed">
                    &ldquo;{item.quote}&rdquo;
                  </blockquote>
                </div>

                {/* Deliverables List */}
                <div className="pt-6 border-t border-white/[0.08]">
                  <span className="text-[10px] font-mono-code text-zinc-400 uppercase tracking-widest block mb-2">
                    KEY OUTCOMES
                  </span>
                  <div className="space-y-1.5">
                    {item.deliverables.map((deliv, dIdx) => (
                      <div key={dIdx} className="text-xs font-mono-code text-zinc-300 flex items-center gap-2">
                        <span className="w-1 h-1 rounded-full bg-cyan-400" />
                        <span>{deliv}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
