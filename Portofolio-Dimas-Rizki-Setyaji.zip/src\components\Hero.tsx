'use client';

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import Image from 'next/image';
import Link from 'next/link';
import {
  ArrowRight,
  ShieldCheck,
  Sparkles,
  Palette,
  Award,
  BookOpen,
  Send,
  Flame,
  Layers,
  CheckCircle2
} from 'lucide-react';
import { PORTFOLIO_DATA } from '@/data/portfolio-data';
import { useApp } from '@/context/AppContext';
import { DICTIONARY } from '@/data/translations';

export default function Hero() {
  const [activeLens, setActiveLens] = useState<'creative' | 'technical'>('creative');
  const { language, theme } = useApp();
  const t = DICTIONARY[language].hero;

  const metrics = [
    {
      value: t.statCore,
      label: t.statCoreLabel,
      icon: Layers,
      color: 'text-cyan-600 dark:text-cyan-400',
      bg: 'bg-cyan-100/80 dark:bg-cyan-500/10 border-cyan-300 dark:border-cyan-500/20'
    },
    {
      value: t.statMedal,
      label: t.statMedalLabel,
      icon: Award,
      color: 'text-amber-600 dark:text-amber-400',
      bg: 'bg-amber-100/80 dark:bg-amber-500/10 border-amber-300 dark:border-amber-500/20'
    },
    {
      value: t.statAssets,
      label: t.statAssetsLabel,
      icon: Sparkles,
      color: 'text-purple-600 dark:text-purple-400',
      bg: 'bg-purple-100/80 dark:bg-purple-500/10 border-purple-300 dark:border-purple-500/20'
    },
    {
      value: t.statSec,
      label: t.statSecLabel,
      icon: ShieldCheck,
      color: 'text-emerald-600 dark:text-emerald-400',
      bg: 'bg-emerald-100/80 dark:bg-emerald-500/10 border-emerald-300 dark:border-emerald-500/20'
    }
  ];

  return (
    <section className="relative min-h-[90vh] flex items-center justify-center pt-24 pb-12 md:pt-32 md:pb-16 overflow-hidden">
      {/* Ambient Gradient Glows & Cyber Pattern */}
      <div className="absolute top-1/4 left-1/4 -translate-x-1/2 -translate-y-1/2 w-[650px] h-[450px] bg-cyan-500/10 dark:bg-cyan-500/15 blur-[160px] pointer-events-none -z-10" />
      <div className="absolute top-1/2 right-1/4 w-[550px] h-[400px] bg-blue-600/10 dark:bg-indigo-600/15 blur-[170px] pointer-events-none -z-10" />
      <div className="absolute inset-0 bg-grid-pattern opacity-35 pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-6 md:px-12 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          {/* Left Column: Bold Editorial Headline, Tagline, & CTAs */}
          <div className="lg:col-span-7 flex flex-col justify-center">
            {/* Identity & Verified Authority Pill */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className={`inline-flex items-center gap-2.5 px-3.5 py-1.5 rounded-full border backdrop-blur-md mb-6 self-start ${
                theme === 'light'
                  ? 'bg-zinc-100/90 border-zinc-300 text-zinc-900 shadow-xs'
                  : 'bg-white/[0.04] border-white/[0.08] text-white'
              }`}
            >
              <span className="h-2 w-2 rounded-full bg-cyan-500 animate-pulse" />
              <span className="text-xs font-mono-code font-bold tracking-wider uppercase">
                DIMAS RIZKI SETYAJI
              </span>
              <span className="text-zinc-400 dark:text-zinc-500">·</span>
              <span className="text-[11px] font-mono-code font-semibold text-cyan-600 dark:text-cyan-400">
                {t.location}
              </span>
            </motion.div>

            {/* Editorial Headline */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="mb-4"
            >
              <h1 className="font-editorial text-4xl sm:text-5xl md:text-6xl lg:text-[62px] font-extrabold tracking-[-0.035em] leading-[1.05] text-zinc-950 dark:text-white">
                {t.titleLine1} <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-600 via-blue-600 to-indigo-600 dark:from-cyan-400 dark:via-blue-500 dark:to-indigo-400">
                  {t.titleLine2}
                </span>{' '}
                <br />
                <span className="text-zinc-950 dark:text-transparent dark:bg-clip-text dark:bg-gradient-to-r dark:from-white dark:via-zinc-200 dark:to-zinc-400">
                  {t.titleLine3}
                </span>
              </h1>
            </motion.div>

            {/* Highlighted Tagline */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.15 }}
              className="mb-6 flex items-center gap-2"
            >
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-cyan-500/10 border border-cyan-500/20 text-cyan-700 dark:text-cyan-300 text-xs font-mono-code font-bold tracking-wider">
                <Sparkles className="w-3.5 h-3.5 text-cyan-500" />
                <span>{t.tagline}</span>
              </div>
            </motion.div>

            {/* Interactive Dual-Mode Lens Switcher */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className={`mb-8 p-2.5 rounded-2xl border backdrop-blur-md max-w-lg ${
                theme === 'light'
                  ? 'bg-zinc-50 border-zinc-300 shadow-xs'
                  : 'bg-white/[0.02] border-white/[0.08]'
              }`}
            >
              <div className="grid grid-cols-2 gap-1.5 mb-2">
                <button
                  onClick={() => setActiveLens('creative')}
                  className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-mono-code transition-all ${
                    activeLens === 'creative'
                      ? theme === 'light'
                        ? 'bg-zinc-950 text-white font-bold shadow-md'
                        : 'bg-white text-black font-bold shadow-md'
                      : theme === 'light'
                      ? 'text-zinc-600 hover:text-zinc-950 hover:bg-zinc-200/60 font-semibold'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>{t.lensDesign}</span>
                </button>
                <button
                  onClick={() => setActiveLens('technical')}
                  className={`flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-mono-code transition-all ${
                    activeLens === 'technical'
                      ? theme === 'light'
                        ? 'bg-emerald-600 text-white font-bold shadow-md'
                        : 'bg-cyan-400 text-black font-bold shadow-[0_0_15px_rgba(0,242,254,0.4)]'
                      : theme === 'light'
                      ? 'text-zinc-600 hover:text-zinc-950 hover:bg-zinc-200/60 font-semibold'
                      : 'text-zinc-400 hover:text-white'
                  }`}
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>{t.lensSecurity}</span>
                </button>
              </div>

              <div className="px-3.5 py-2 rounded-xl bg-zinc-200/70 dark:bg-black/40 text-[11px] font-mono-code flex items-center justify-between border border-zinc-300/60 dark:border-white/5">
                {activeLens === 'creative' ? (
                  <span className="text-zinc-900 dark:text-zinc-300 font-medium truncate">{t.lensDesignDesc}</span>
                ) : (
                  <span className="text-emerald-800 dark:text-cyan-300 font-medium truncate">{t.lensSecurityDesc}</span>
                )}
                <span className="text-zinc-600 dark:text-zinc-400 font-bold shrink-0 ml-2">{t.readyStatus}</span>
              </div>
            </motion.div>

            {/* Dual CTA Action Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.25 }}
              className="flex flex-wrap items-center gap-3.5"
            >
              <Link
                href="#about"
                className="group inline-flex items-center gap-2 px-6 py-3.5 text-xs font-mono-code font-bold tracking-wider text-white bg-zinc-950 dark:text-black dark:bg-white rounded-xl transition-all duration-300 hover:bg-cyan-600 dark:hover:bg-cyan-400 hover:text-white dark:hover:text-black shadow-md hover:shadow-lg hover:scale-[1.02]"
              >
                <Palette className="w-4 h-4" />
                <span>{t.btnPortfolio}</span>
                <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </Link>

              <Link
                href="#contact"
                className="group inline-flex items-center gap-2 px-6 py-3.5 text-xs font-mono-code font-bold tracking-wider text-zinc-900 dark:text-white bg-zinc-100/90 dark:bg-white/[0.05] border border-zinc-300 dark:border-white/10 rounded-xl hover:bg-zinc-200/90 dark:hover:bg-white/10 transition-all duration-300 shadow-xs hover:scale-[1.02]"
              >
                <Send className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
                <span>{t.btnContact}</span>
              </Link>
            </motion.div>
          </div>

          {/* Right Column: Visual Profile Card & Verified Badges */}
          <div className="lg:col-span-5 relative flex items-center justify-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.15 }}
              className="w-full relative rounded-3xl p-6 sm:p-7 cyber-card shadow-lg dark:shadow-[0_20px_50px_rgba(0,0,0,0.8)] overflow-hidden"
            >
              {/* Profile Card Header */}
              <div className="flex items-center gap-4 mb-5 pb-5 border-b border-zinc-200 dark:border-white/[0.08]">
                <div className="relative w-16 h-16 sm:w-20 sm:h-20 rounded-2xl overflow-hidden border-2 border-cyan-500/60 shrink-0 shadow-md">
                  <Image
                    src={PORTFOLIO_DATA.profile.avatar}
                    alt={PORTFOLIO_DATA.profile.name}
                    fill
                    sizes="80px"
                    className="object-cover"
                  />
                </div>
                <div>
                  <div className="flex items-center gap-1.5 mb-1">
                    <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
                    <span className="text-[11px] font-mono-code text-emerald-700 dark:text-emerald-400 tracking-wider font-bold">
                      {t.badgeVerified}
                    </span>
                  </div>
                  <h3 className="text-xl sm:text-2xl font-editorial font-bold leading-tight text-zinc-950 dark:text-white">
                    {PORTFOLIO_DATA.profile.name}
                  </h3>
                  <p className="text-xs font-mono-code text-zinc-600 dark:text-cyan-400/90 font-medium mt-0.5">
                    {t.badgeRole}
                  </p>
                </div>
              </div>

              {/* Verified Institutional & Academic Badges */}
              <div className="space-y-2 mb-5">
                <div className="flex items-center justify-between p-2.5 rounded-xl bg-zinc-50 dark:bg-white/[0.02] border border-zinc-200 dark:border-white/[0.05] text-xs">
                  <div className="flex items-center gap-2.5">
                    <div className="relative w-6 h-6 rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-white/10 p-0.5 shrink-0 flex items-center justify-center overflow-hidden">
                      <Image
                        src="/icons/hits-symbol.svg"
                        alt="HITS Software House"
                        width={22}
                        height={22}
                        className="object-contain"
                      />
                    </div>
                    <span className="font-mono-code font-semibold text-zinc-900 dark:text-zinc-100">{t.hitsTag}</span>
                  </div>
                  <span className="text-[11px] font-mono-code text-cyan-700 dark:text-cyan-400 font-bold">{t.hitsRole}</span>
                </div>

                <div className="flex items-center justify-between p-2.5 rounded-xl bg-zinc-50 dark:bg-white/[0.02] border border-zinc-200 dark:border-white/[0.05] text-xs">
                  <div className="flex items-center gap-2.5">
                    <div className="relative w-6 h-6 rounded-lg bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-white/10 p-0.5 shrink-0 flex items-center justify-center overflow-hidden">
                      <Image
                        src="/icons/unisa-emblem.png"
                        alt="BPTSI CSIRT UNISA"
                        width={22}
                        height={22}
                        className="object-contain"
                      />
                    </div>
                    <span className="font-mono-code font-semibold text-zinc-900 dark:text-zinc-100">{t.csirtTag}</span>
                  </div>
                  <span className="text-[11px] font-mono-code text-emerald-700 dark:text-emerald-400 font-bold">{t.csirtStatus}</span>
                </div>

                <div className="flex items-center justify-between p-2.5 rounded-xl bg-zinc-50 dark:bg-white/[0.02] border border-zinc-200 dark:border-white/[0.05] text-xs">
                  <div className="flex items-center gap-2">
                    <Award className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                    <span className="font-mono-code font-semibold text-zinc-900 dark:text-zinc-100">{t.medalTag}</span>
                  </div>
                  <span className="text-[11px] font-mono-code text-zinc-600 dark:text-zinc-400 font-medium">AST PTMA</span>
                </div>

                <div className="flex items-center justify-between p-2.5 rounded-xl bg-zinc-50 dark:bg-white/[0.02] border border-zinc-200 dark:border-white/[0.05] text-xs">
                  <div className="flex items-center gap-2">
                    <BookOpen className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                    <span className="font-mono-code font-semibold text-zinc-900 dark:text-zinc-100">{t.doiTag}</span>
                  </div>
                  <span className="text-[11px] font-mono-code text-zinc-600 dark:text-zinc-400 font-medium">NIST & Docker</span>
                </div>
              </div>

              {/* Direct Lab Switcher */}
              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-zinc-200 dark:border-white/[0.06]">
                <Link
                  href="/design"
                  className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-cyan-100/90 dark:bg-cyan-500/10 border border-cyan-300 dark:border-cyan-500/30 text-cyan-900 dark:text-cyan-300 hover:bg-cyan-600 hover:text-white dark:hover:bg-cyan-400 dark:hover:text-black transition-all text-xs font-mono-code font-bold shadow-xs"
                >
                  <Palette className="w-3.5 h-3.5" />
                  <span>{t.lensDesign}</span>
                </Link>
                <Link
                  href="/security"
                  className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-emerald-100/90 dark:bg-emerald-500/10 border border-emerald-300 dark:border-emerald-500/30 text-emerald-900 dark:text-emerald-300 hover:bg-emerald-600 hover:text-white dark:hover:bg-emerald-500 dark:hover:text-black transition-all text-xs font-mono-code font-bold shadow-xs"
                >
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>{t.lensSecurity}</span>
                </Link>
              </div>
            </motion.div>
          </div>
        </div>

        {/* 4 Interactive Metrics Counter Ribbon */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="mt-12 pt-8 border-t border-zinc-200 dark:border-white/[0.08] grid grid-cols-2 md:grid-cols-4 gap-4"
        >
          {metrics.map((item, idx) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={idx}
                whileHover={{ y: -3, scale: 1.02 }}
                transition={{ duration: 0.2 }}
                className="p-5 rounded-2xl cyber-card text-center shadow-xs flex flex-col items-center justify-center group"
              >
                <div className={`w-8 h-8 rounded-xl ${item.bg} border flex items-center justify-center mb-2.5 group-hover:scale-110 transition-transform`}>
                  <Icon className={`w-4 h-4 ${item.color}`} />
                </div>
                <span className="text-xl sm:text-2xl font-editorial font-extrabold text-zinc-950 dark:text-white block">
                  {item.value}
                </span>
                <span className="text-[10.5px] font-mono-code text-zinc-600 dark:text-zinc-400 font-bold uppercase tracking-wider mt-1 block">
                  {item.label}
                </span>
              </motion.div>
            );
          })}
        </motion.div>
      </div>
    </section>
  );
}
