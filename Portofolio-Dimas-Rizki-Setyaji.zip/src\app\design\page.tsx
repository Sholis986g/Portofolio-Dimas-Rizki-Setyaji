'use client';

import React from 'react';
import Navbar from '@/components/Navbar';
import VisualGallery from '@/components/VisualGallery';
import Contact from '@/components/Contact';
import Footer from '@/components/Footer';
import PageTransition from '@/components/PageTransition';
import Image from 'next/image';
import { Palette } from 'lucide-react';
import { PORTFOLIO_DATA } from '@/data/portfolio-data';
import ToolIcon from '@/components/ToolIcon';
import { useApp } from '@/context/AppContext';

export default function DesignPage() {
  const { language } = useApp();
  const designProjects = PORTFOLIO_DATA.projects.filter(
    (p) => p.tag === 'DESIGN' || p.category.includes('Design') || p.category.includes('Marketing') || p.category.includes('Brand')
  );

  return (
    <PageTransition>
      <main className="min-h-screen bg-[var(--bg-primary)] text-[var(--text-primary)] flex flex-col relative selection:bg-cyan-400 selection:text-black">
        {/* Navigation */}
        <Navbar />

      {/* Hero Banner for Design Portfolio */}
      <section className="relative pt-32 pb-16 md:pt-40 md:pb-24 border-b border-black/10 dark:border-white/[0.08] overflow-hidden bg-gradient-to-b from-black/[0.03] to-transparent dark:from-[#080d1a] dark:to-[#050505]">
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[450px] bg-gradient-to-tr from-cyan-500/10 via-blue-500/10 to-transparent blur-[160px] pointer-events-none" />
        <div className="absolute inset-0 bg-grid-pattern opacity-15 dark:opacity-25 pointer-events-none" />

        <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
          <div className="flex items-center gap-2 mb-4">
            <span className="p-1 rounded bg-cyan-500/10 text-cyan-700 dark:text-cyan-400 border border-cyan-500/30">
              <Palette className="w-3.5 h-3.5" />
            </span>
            <span className="text-xs font-mono-code uppercase tracking-[0.25em] text-cyan-700 dark:text-cyan-400 font-bold">
              {language === 'id' ? 'LAB IDENTITAS VISUAL & KREATIF' : 'CREATIVE & VISUAL IDENTITY LAB'}
            </span>
          </div>

          <h1 className="font-editorial text-4xl sm:text-6xl md:text-7xl font-extrabold tracking-tight mb-6 leading-[1.05] text-zinc-950 dark:text-white">
            {language === 'id' ? (
              <>
                DESAIN GRAFIS, BRANDING <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-600 via-blue-600 to-indigo-600 dark:from-cyan-400 dark:via-blue-500 dark:to-indigo-500">
                  & SHOWCASE UI/UX.
                </span>
              </>
            ) : (
              <>
                GRAPHIC DESIGN, BRANDING <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-600 via-blue-600 to-indigo-600 dark:from-cyan-400 dark:via-blue-500 dark:to-indigo-500">
                  & UI/UX SHOWCASE.
                </span>
              </>
            )}
          </h1>

          <p className="text-base sm:text-lg text-zinc-700 dark:text-zinc-300 font-normal leading-relaxed max-w-2xl mb-8">
            {language === 'id'
              ? 'Kumpulan karya visual kreatif oleh Dimas Rizki Setyaji — mencakup desain media sosial institusional (BEM FST & PMB UNISA), identitas visual, kampanye promosi, large format print, apparel merchandise streetwear, dan antarmuka web modern.'
              : 'Collection of creative visual works by Dimas Rizki Setyaji — including institutional social media design (BEM FST & PMB UNISA), visual identities, promotional campaigns, large format prints, streetwear apparel merchandise, and modern web UI/UX.'}
          </p>

          <div className="flex flex-wrap items-center gap-4 text-xs font-mono-code text-zinc-600 dark:text-zinc-400">
            <span className="px-3 py-1 rounded-full bg-zinc-100 dark:bg-white/[0.04] border border-zinc-300 dark:border-white/10 text-zinc-800 dark:text-zinc-200 font-medium">
              ✦ Adobe Photoshop & Illustrator
            </span>
            <span className="px-3 py-1 rounded-full bg-zinc-100 dark:bg-white/[0.04] border border-zinc-300 dark:border-white/10 text-zinc-800 dark:text-zinc-200 font-medium">
              ✦ Canva Pro & Figma
            </span>
            <span className="px-3 py-1 rounded-full bg-zinc-100 dark:bg-white/[0.04] border border-zinc-300 dark:border-white/10 text-zinc-800 dark:text-zinc-200 font-medium">
              ✦ CMYK Print & Vector Separations
            </span>
          </div>
        </div>
      </section>

      {/* Main Interactive Visual Gallery Component */}
      <VisualGallery />

      {/* Detailed Design Case Studies Grid */}
      <section className="py-24 md:py-32 relative border-t border-zinc-200 dark:border-white/[0.06]">
        <div className="max-w-7xl mx-auto px-6 md:px-12">
          <div className="mb-12">
            <div className="flex items-center gap-2 mb-3">
              <span className="h-2 w-2 rounded-full bg-cyan-500 animate-pulse" />
              <span className="text-xs font-mono-code uppercase tracking-[0.25em] text-cyan-700 dark:text-cyan-400 font-bold">
                {language === 'id' ? 'STUDI KASUS BRAND UTAMA' : 'FEATURED BRAND CASE STUDIES'}
              </span>
            </div>
            <h2 className="text-3xl md:text-5xl font-editorial font-extrabold tracking-tight text-zinc-950 dark:text-white">
              {language === 'id' ? 'KAMPANYE & SISTEM VISUAL' : 'DETAILED CAMPAIGNS & SYSTEMS'}
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {designProjects.map((project) => (
              <div
                key={project.id}
                className="rounded-3xl cyber-card overflow-hidden transition-all flex flex-col justify-between shadow-sm"
              >
                <div className="relative w-full h-64 bg-zinc-100 dark:bg-black/60">
                  <Image
                    src={project.image}
                    alt={project.title}
                    fill
                    sizes="(max-width: 768px) 100vw, 50vw"
                    className="object-cover"
                  />
                  <div className="absolute top-4 left-4">
                    <span className="px-3 py-1 text-[10px] font-mono-code font-bold rounded-full bg-black/80 border border-white/20 text-cyan-300 backdrop-blur-md">
                      {project.category}
                    </span>
                  </div>
                </div>

                <div className="p-6 md:p-8 flex flex-col justify-between flex-1">
                  <div>
                    <h3 className="text-2xl font-editorial font-bold mb-2 text-zinc-950 dark:text-white">
                      {project.title}
                    </h3>
                    <p className="text-xs sm:text-sm text-zinc-700 dark:text-zinc-300 font-normal leading-relaxed mb-6">
                      {project.fullDescription}
                    </p>

                    <div className="p-4 rounded-2xl bg-cyan-50 dark:bg-cyan-500/[0.04] border border-cyan-200 dark:border-cyan-500/20 mb-6">
                      <span className="text-[10px] font-mono-code text-cyan-800 dark:text-cyan-400 font-bold uppercase tracking-widest block mb-1">
                        {language === 'id' ? 'DAMPAK & PENCAPAIAN' : 'IMPACT & ACHIEVEMENTS'}
                      </span>
                      <p className="text-xs text-zinc-800 dark:text-zinc-200 font-medium">
                        {project.impact}
                      </p>
                    </div>
                  </div>

                  <div className="pt-4 border-t border-zinc-200 dark:border-white/[0.08] flex flex-wrap gap-1.5">
                    {project.technologies.map((t) => (
                      <span
                        key={t}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 text-[10px] font-mono-code font-medium rounded-lg bg-zinc-100 dark:bg-white/[0.04] text-zinc-800 dark:text-zinc-300 border border-zinc-300 dark:border-white/[0.08]"
                      >
                        <ToolIcon name={t} className="w-3.5 h-3.5 shrink-0" />
                        <span>{t}</span>
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact */}
      <Contact />

      {/* Footer */}
      <Footer />
    </main>
    </PageTransition>
  );
}
