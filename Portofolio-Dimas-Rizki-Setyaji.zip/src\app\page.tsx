'use client';

import React from 'react';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import About from '@/components/About';
import InteractiveSkillsMatrix from '@/components/InteractiveSkillsMatrix';
import Publications from '@/components/Publications';
import Experience from '@/components/Experience';
import Contact from '@/components/Contact';
import Footer from '@/components/Footer';
import PageTransition from '@/components/PageTransition';

export default function Home() {
  return (
    <PageTransition>
      <main className="min-h-screen bg-[var(--bg-primary)] text-[var(--text-primary)] flex flex-col relative selection:bg-cyan-400 selection:text-black transition-colors duration-300">
        {/* Top Navbar with Page Switcher */}
        <Navbar />

        {/* Hero Section with Quick Labs & Profile Card */}
        <Hero />

        {/* Executive Bento Grid (About, Achievements, Papers, Production Stats) */}
        <About />

        {/* Core Arsenal & Interactive Capabilities Matrix */}
        <InteractiveSkillsMatrix />

        {/* Peer-Reviewed Scientific Publications */}
        <Publications />

        {/* Experience, Awards & Education Track */}
        <Experience />

        {/* Direct Contact & Transmission Form */}
        <Contact />

        {/* Footer */}
        <Footer />
      </main>
    </PageTransition>
  );
}
