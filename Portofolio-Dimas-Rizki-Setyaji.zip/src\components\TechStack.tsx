'use client';

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Layers, CheckCircle2, Sparkles, Code2, Server, Shield } from 'lucide-react';
import { PORTFOLIO_DATA } from '@/data/portfolio-data';
import ToolIcon from '@/components/ToolIcon';

export default function TechStack() {
  const { techStack } = PORTFOLIO_DATA;
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  const categories = ['ALL', ...techStack.categories.map((c) => c.name)];

  const displayedCategories =
    selectedCategory === 'ALL'
      ? techStack.categories
      : techStack.categories.filter((c) => c.name === selectedCategory);

  const getCategoryIcon = (name: string) => {
    if (name.includes('DESIGN')) return <Sparkles className="w-4 h-4 text-cyan-400" />;
    if (name.includes('DEVELOPMENT')) return <Code2 className="w-4 h-4 text-blue-400" />;
    if (name.includes('INFRASTRUCTURE')) return <Server className="w-4 h-4 text-indigo-400" />;
    return <Shield className="w-4 h-4 text-emerald-400" />;
  };

  return (
    <section id="tech" className="py-24 md:py-32 relative border-t border-white/[0.06] bg-[#050816]/30">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-6">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="h-1.5 w-1.5 rounded-full bg-cyan-400" />
              <span className="text-xs font-mono-code uppercase tracking-[0.25em] text-zinc-400">
                06 / ARSENAL
              </span>
            </div>
            <h2 className="text-4xl md:text-6xl font-editorial font-extrabold tracking-tight text-white">
              TECHNOLOGY STACK
            </h2>
          </div>

          {/* Filter Pills */}
          <div className="flex flex-wrap items-center gap-1.5 p-1.5 bg-white/[0.03] border border-white/[0.08] rounded-2xl backdrop-blur-md">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-mono-code transition-all ${
                  selectedCategory === cat
                    ? 'bg-white text-black font-semibold shadow-md'
                    : 'text-zinc-400 hover:text-white hover:bg-white/[0.05]'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Stack Categories Grid */}
        <div className="space-y-12">
          {displayedCategories.map((cat, cIdx) => (
            <motion.div
              key={cat.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: cIdx * 0.1 }}
              className="p-8 md:p-10 rounded-3xl bg-[#090d16]/60 border border-white/[0.08] backdrop-blur-xl"
            >
              {/* Category Title */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-8 pb-6 border-b border-white/[0.08]">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-white/[0.05] border border-white/10">
                    {getCategoryIcon(cat.name)}
                  </div>
                  <div>
                    <h3 className="text-2xl font-editorial font-bold text-white tracking-wide">
                      {cat.name}
                    </h3>
                    <p className="text-xs font-mono-code text-zinc-400 mt-0.5">
                      {cat.description}
                    </p>
                  </div>
                </div>
                <span className="text-xs font-mono-code text-zinc-500">
                  {cat.skills.length} MODULES
                </span>
              </div>

              {/* Skills Interactive Badges */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {cat.skills.map((skill, sIdx) => (
                  <div
                    key={skill.name}
                    className="group p-4 rounded-2xl bg-white/[0.02] border border-white/[0.06] hover:bg-white/[0.06] hover:border-cyan-400/40 transition-all duration-300 flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2.5">
                          <div className="w-7 h-7 rounded-lg overflow-hidden shrink-0 flex items-center justify-center shadow-md bg-black/40">
                            <ToolIcon name={skill.name} className="w-6 h-6" />
                          </div>
                          <h4 className="text-sm font-editorial font-bold text-white group-hover:text-cyan-200 transition-colors">
                            {skill.name}
                          </h4>
                        </div>
                        <span className="text-[9px] font-mono-code px-2 py-0.5 rounded bg-cyan-400/10 text-cyan-300 border border-cyan-400/20">
                          {skill.level}
                        </span>
                      </div>
                      <p className="text-xs text-zinc-400 font-light leading-relaxed">
                        {skill.desc}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
