'use client';

import React from 'react';
import { motion } from 'framer-motion';
import Image from 'next/image';
import { Briefcase, Award, GraduationCap } from 'lucide-react';
import { PORTFOLIO_DATA } from '@/data/portfolio-data';
import { useApp } from '@/context/AppContext';
import { DICTIONARY } from '@/data/translations';

export default function Experience() {
  const { experience, achievements, education } = PORTFOLIO_DATA;
  const { language } = useApp();
  const t = DICTIONARY[language].experience;

  return (
    <section id="experience" className="py-20 md:py-28 relative border-t border-black/10 dark:border-white/[0.08]">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-12 gap-4 pb-4 border-b border-zinc-200 dark:border-white/[0.06]">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="h-2 w-2 rounded-full bg-cyan-500 animate-pulse" />
              <span className="text-xs font-mono-code uppercase tracking-[0.25em] text-cyan-700 dark:text-cyan-400 font-bold">
                {t.eyebrow}
              </span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-editorial font-extrabold tracking-tight text-zinc-950 dark:text-white">
              {t.title}
            </h2>
          </div>
          <span className="text-xs font-mono-code text-zinc-600 dark:text-zinc-400 font-semibold">
            PROVEN INDUSTRY & ACADEMIC ACHIEVEMENTS
          </span>
        </div>

        {/* 2-Column High-Impact Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left: Work Experience Timeline (7 cols) */}
          <div className="lg:col-span-7 space-y-4">
            <div className="text-xs font-mono-code text-zinc-600 dark:text-zinc-400 font-bold uppercase tracking-widest mb-3 flex items-center gap-2">
              <Briefcase className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
              <span>{t.filterExp}</span>
            </div>

            {experience.map((item, idx) => (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: idx * 0.08 }}
                className="p-6 rounded-3xl cyber-card group shadow-sm"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                  <span className="px-3 py-1 text-[11px] font-mono-code font-bold rounded-full bg-cyan-100/90 text-cyan-800 dark:bg-cyan-500/10 dark:text-cyan-300 border border-cyan-300 dark:border-cyan-500/20">
                    {item.badge}
                  </span>
                  <span className="text-xs font-mono-code text-zinc-500 font-semibold">
                    {item.period}
                  </span>
                </div>

                <div className="flex items-start gap-4 mb-3">
                  {item.logo ? (
                    <div className="relative w-12 h-12 rounded-2xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-white/10 p-2 shrink-0 flex items-center justify-center shadow-xs overflow-hidden">
                      <Image
                        src={item.logo}
                        alt={item.company}
                        width={40}
                        height={40}
                        className="object-contain w-full h-full"
                      />
                    </div>
                  ) : (
                    <div className="w-12 h-12 rounded-2xl bg-zinc-100 dark:bg-white/[0.04] border border-zinc-200 dark:border-white/[0.08] flex items-center justify-center shrink-0 text-cyan-600 dark:text-cyan-400 font-mono-code font-bold text-xs">
                      {item.company.slice(0, 2).toUpperCase()}
                    </div>
                  )}

                  <div className="flex-1 min-w-0">
                    <h3 className="text-lg sm:text-xl font-editorial font-bold mb-0.5 text-zinc-950 dark:text-white group-hover:text-cyan-700 dark:group-hover:text-cyan-200 transition-colors">
                      {item.role}
                    </h3>
                    <div className="text-xs font-mono-code text-cyan-700 dark:text-cyan-400/90 font-medium">
                      {item.company} · {item.location}
                    </div>
                  </div>
                </div>

                <p className="text-xs text-zinc-600 dark:text-zinc-400 font-normal leading-relaxed mb-3">
                  {item.description}
                </p>

                <div className="flex flex-wrap gap-1.5 pt-3 border-t border-zinc-200 dark:border-white/[0.06]">
                  {item.skills.map((s) => (
                    <span
                      key={s}
                      className="px-2.5 py-1 text-[11px] font-mono-code rounded-lg bg-zinc-100 dark:bg-white/[0.03] border border-zinc-200 dark:border-white/[0.06] text-zinc-800 dark:text-zinc-300 font-medium"
                    >
                      {s}
                    </span>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>

          {/* Right: Honors & Education (5 cols) */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            {/* National Medals */}
            <div>
              <div className="text-xs font-mono-code text-zinc-600 dark:text-zinc-400 font-bold uppercase tracking-widest mb-3 flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                <span>{t.filterAwards}</span>
              </div>

              <div className="space-y-3">
                {achievements.map((ach, idx) => (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, y: 15 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: idx * 0.08 }}
                    className="p-5 rounded-3xl cyber-card flex items-center justify-between gap-4 group shadow-sm"
                  >
                    <div>
                      <div className="text-[11px] font-mono-code text-amber-700 dark:text-amber-400 font-bold mb-0.5">
                        {ach.year} · {ach.category}
                      </div>
                      <h4 className="text-base font-editorial font-bold mb-1 text-zinc-950 dark:text-white">
                        {ach.title}
                      </h4>
                      <p className="text-xs text-zinc-600 dark:text-zinc-400 font-normal">
                        {ach.description}
                      </p>
                    </div>
                    <span className="px-3 py-1.5 text-[11px] font-mono-code font-bold rounded-xl bg-amber-100/90 text-amber-800 dark:bg-amber-500/10 dark:text-amber-300 border border-amber-300 dark:border-amber-500/20 shrink-0">
                      {ach.award}
                    </span>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Education Track */}
            <div>
              <div className="text-xs font-mono-code text-zinc-600 dark:text-zinc-400 font-bold uppercase tracking-widest mb-3 flex items-center gap-2">
                <GraduationCap className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                <span>{t.filterEdu}</span>
              </div>

              <div className="space-y-3">
                {education.map((edu, idx) => (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, y: 15 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.4, delay: idx * 0.08 }}
                    className="p-5 rounded-3xl cyber-card shadow-sm flex items-start gap-3.5"
                  >
                    {edu.logo ? (
                      <div className="relative w-10 h-10 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-white/10 p-1.5 shrink-0 flex items-center justify-center shadow-xs overflow-hidden">
                        <Image
                          src={edu.logo}
                          alt={edu.institution}
                          width={32}
                          height={32}
                          className="object-contain w-full h-full"
                        />
                      </div>
                    ) : (
                      <div className="w-10 h-10 rounded-xl bg-zinc-100 dark:bg-white/[0.04] border border-zinc-200 dark:border-white/[0.08] flex items-center justify-center shrink-0 text-blue-600 dark:text-blue-400 font-mono-code font-bold text-xs">
                        <GraduationCap className="w-4 h-4" />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <h4 className="text-sm font-editorial font-bold text-zinc-950 dark:text-white">
                          {edu.institution}
                        </h4>
                        <span className="text-[11px] font-mono-code text-zinc-500 font-semibold shrink-0">
                          {edu.period}
                        </span>
                      </div>
                      <div className="text-xs font-mono-code text-cyan-700 dark:text-cyan-400 font-bold mb-1">
                        {edu.degree}
                      </div>
                      <p className="text-xs text-zinc-600 dark:text-zinc-400 font-normal">
                        {edu.focus}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
