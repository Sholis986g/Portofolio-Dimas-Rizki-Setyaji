export interface Project {
  id: string;
  number: string;
  title: string;
  category: string;
  tag: 'DESIGN' | 'DEVELOPMENT' | 'CYBERSECURITY' | 'PHOTOGRAPHY';
  image: string;
  secondaryImage?: string;
  galleryImages?: string[];
  shortDescription: string;
  fullDescription: string;
  impact: string;
  technologies: string[];
  year: string;
  role: string;
  client?: string;
  featured: boolean;
  metrics?: { label: string; value: string }[];
  accentColor: string;
  architectureDetails?: string[];
  securityConsiderations?: string[];
}

export interface GalleryItem {
  id: string;
  title: string;
  category: 'SOCIAL' | 'UI/UX' | 'PRINT';
  categoryLabel: string;
  image: string;
  aspect: 'square' | 'portrait' | 'landscape' | 'wide';
  caption: string;
  tools: string[];
  cameraExif?: string;
}

export interface SecurityAnalysisModule {
  id: string;
  category: 'WEB SECURITY' | 'DIGITAL FORENSICS' | 'OSINT' | 'NETWORK SECURITY';
  title: string;
  summary: string;
  status: 'OPTIMIZED' | 'VERIFIED' | 'ANALYZING' | 'HARDENED';
  cveOrStandard?: string;
  details: string;
  findings: string[];
  mitigations: string[];
  commandSample?: string;
  attackChainDiagram?: { step: string; label: string; desc: string }[];
}

export interface ExperienceItem {
  id: string;
  period: string;
  role: string;
  company: string;
  location: string;
  badge: string;
  logo?: string;
  description: string;
  achievements: string[];
  skills: string[];
}

export interface PublicationItem {
  id: string;
  title: string;
  journal: string;
  year: string;
  volume: string;
  doi: string;
  doiUrl: string;
  category: 'CYBERSECURITY & FORENSICS' | 'CONTAINERIZATION & DEVOPS';
  authors: string[];
  summary: string;
  keyFindings: string[];
  tags: string[];
}

export const PORTFOLIO_DATA: {
  profile: {
    name: string;
    nickname: string;
    label: string;
    headline: string;
    subheadline: string;
    status: string;
    systemStatus: string;
    avatar: string;
    stats: { label: string; value: string }[];
    socialLinks: {
      email: string;
      phone: string;
      github: string;
      linkedin: string;
      instagram: string;
      contra: string;
    };
  };
  about: {
    title: string;
    tagline: string;
    bioShort: string;
    highlights: { title: string; subtitle: string; icon: string }[];
    pillars: { num: string; title: string; desc: string; icon: string }[];
  };
  gallery: GalleryItem[];
  projects: Project[];
  expertise: {
    id: string;
    pillar: string;
    headline: string;
    tagline: string;
    accent: string;
    image?: string;
    description: string;
    skills: string[];
    disciplines: string[];
    icon: string;
  }[];
  securityLab: {
    title: string;
    subtitle: string;
    description: string;
    modules: SecurityAnalysisModule[];
  };
  philosophy: {
    step: string;
    name: string;
    label: string;
    summary: string;
    quote: string;
    deliverables: string[];
  }[];
  techStack: {
    categories: {
      name: string;
      description: string;
      skills: { name: string; level: string; desc: string }[];
    }[];
  };
  experience: ExperienceItem[];
  publications: PublicationItem[];
  achievements: {
    year: string;
    title: string;
    category: string;
    award: string;
    description: string;
  }[];
  education: {
    institution: string;
    degree: string;
    period: string;
    focus: string;
    logo?: string;
  }[];
} = {
  profile: {
    name: "Dimas Rizki Setyaji",
    nickname: "Dimas",
    label: "CREATIVE DESIGNER × FULL STACK × CYBERSECURITY",
    headline: "DESIGNING DIGITAL EXPERIENCES WITH ARCHITECTURAL & DEFENSIVE DEPTH.",
    subheadline:
      "Crafting high-impact brand identities, scalable web applications, and hardened defensive security architectures.",
    status: "AVAILABLE FOR WORK",
    systemStatus: "CSIRT VERIFIED",
    avatar: "/images/avatar_dimas.webp",
    stats: [
      { label: "Core Fields", value: "Design · Code · Sec" },
      { label: "National Awards", value: "2x Silver Medal" },
      { label: "Design & UI Assets", value: "350+ Produced" },
      { label: "Security & Systems", value: "CSIRT Active" },
    ],
    socialLinks: {
      email: "dimasrizkisetyaji@gmail.com",
      phone: "+62 822-3444-1456",
      github: "https://github.com/Sholis986g",
      linkedin: "https://linkedin.com/in/dimas-rizki-setyaji",
      instagram: "https://instagram.com/dimrizji",
      contra: "https://contra.com/ahmad_sholis_ytniarg5/about?r=ahmad_sholis_ytniarg5"
    }
  },

  about: {
    title: "ABOUT ME",
    tagline: "CREATIVE VISION × SYSTEM DEFENSE",
    bioShort:
      "S1 TI UNISA Yogyakarta & Multimedia SMKN 1 Cerme. Menghubungkan estetika visual, web engineering, dan digital forensic CSIRT.",
    highlights: [
      {
        title: "Creative Design",
        subtitle: "Brand identity, social campaigns & UI/UX prototyping",
        icon: "Palette"
      },
      {
        title: "Full-Stack Dev",
        subtitle: "PHP, Laravel, WordPress, Docker & Linux systems",
        icon: "Code2"
      },
      {
        title: "CSIRT & Forensics",
        subtitle: "NIST SP 800-86, OWASP hardening & triage insiden",
        icon: "ShieldCheck"
      }
    ],
    pillars: [
      {
        num: "01",
        title: "Visual System",
        desc: "Identitas visual, tipografi editorial, kampanye multi-kanal & UI/UX Figma.",
        icon: "Palette"
      },
      {
        num: "02",
        title: "Dev & Containers",
        desc: "Docker bridge, API bridging BPJS Kesehatan, arsitektur Laravel & WordPress.",
        icon: "Code2"
      },
      {
        num: "03",
        title: "CSIRT Defense",
        desc: "Forensik NIST SP 800-86, analisis hash SHA-256 & mitigasi OWASP.",
        icon: "ShieldCheck"
      }
    ]
  },

  gallery: [
    {
      id: "gal-01",
      title: "Vitalife Healthcare Web Platform",
      category: "UI/UX",
      categoryLabel: "UI/UX & Web Portal",
      image: "/images/project_vitalife_web.webp",
      aspect: "wide",
      caption: "Clean, responsive modern healthcare portal UI designed in Figma with medical scheduling workflow.",
      tools: ["Figma", "UI/UX", "WordPress", "Tailwind CSS"]
    },
    {
      id: "gal-02",
      title: "Vitalife Mobile Experience",
      category: "UI/UX",
      categoryLabel: "Mobile App UI",
      image: "/images/project_vitalife_mobile.webp",
      aspect: "portrait",
      caption: "Mobile appointment booking interface optimized for accessibility and touch interactions.",
      tools: ["Figma", "Mobile UI", "Prototyping"]
    },
    {
      id: "gal-03",
      title: "Culinary & Food Brand Visual Design",
      category: "SOCIAL",
      categoryLabel: "Food & Brand Visual",
      image: "/images/social_pmb_1.webp",
      aspect: "square",
      caption: "High-contrast culinary promotion & food branding visual designed for appetizing presentation and engagement.",
      tools: ["Adobe Photoshop", "Illustrator", "Brand Visual"]
    },
    {
      id: "gal-04",
      title: "Scholarship & Academic Promotion",
      category: "SOCIAL",
      categoryLabel: "Editorial Social Graphics",
      image: "/images/social_pmb_2.webp",
      aspect: "square",
      caption: "Academic scholarship visual campaign designed for high readability and mobile feed engagement.",
      tools: ["Canva Pro", "Photoshop", "Typography"]
    },
    {
      id: "gal-05",
      title: "Talkshow: Trace The Truth — Event Poster",
      category: "SOCIAL",
      categoryLabel: "Campus Event Poster",
      image: "/images/poster_talkshow_trace_the_truth.webp",
      aspect: "portrait",
      caption: "Official event poster for 'Trace The Truth: Isu Infrastruktur di Lingkungan Kampus' featuring dual keynote speakers in dramatic red-black duotone lighting.",
      tools: ["Photoshop", "Typography", "Duotone Lighting", "Brand System"]
    },
    {
      id: "gal-06",
      title: "National Seminar 6x1.75m Banner",
      category: "PRINT",
      categoryLabel: "Large Format Print",
      image: "/images/print_banner_horizontal.webp",
      aspect: "wide",
      caption: "Large-format 6x1.75 meter print backdrop designed with high-resolution CMYK vector fidelity.",
      tools: ["Adobe Illustrator", "Photoshop", "Large Format Print"]
    },
    {
      id: "gal-07",
      title: "Institutional Rollup X-Banner",
      category: "PRINT",
      categoryLabel: "Exhibition X-Banner",
      image: "/images/print_xbanner.webp",
      aspect: "portrait",
      caption: "Vertical exhibition banner with structured typographic hierarchy and clear institutional identity.",
      tools: ["Adobe Illustrator", "Print Prep", "CMYK"]
    },
    {
      id: "gal-08",
      title: "Kaos Pro Apparel Typography",
      category: "PRINT",
      categoryLabel: "Apparel & Merchandise",
      image: "/images/print_kaos_pro_1.webp",
      aspect: "square",
      caption: "Custom streetwear and organizational apparel design with vector typography and screen print separations.",
      tools: ["Adobe Illustrator", "Vector Graphics", "Apparel"]
    }
  ],

  projects: [
    {
      id: "project-01",
      number: "01",
      title: "Vitalife & BPJS Healthcare Queue System",
      category: "DEVOPS / WEB PORTAL / HEALTHCARE",
      tag: "DEVELOPMENT",
      image: "/images/project_vitalife_web.webp",
      secondaryImage: "/images/project_vitalife_mobile.webp",
      galleryImages: ["/images/project_vitalife_web.webp", "/images/project_vitalife_mobile.webp"],
      shortDescription:
        "Dockerized online queue management portal integrated with national BPJS healthcare bridging APIs for RSU Queen Latifa.",
      fullDescription:
        "Architected server environments and front-end bridging components for RSU Queen Latifa. Deployed multi-container Docker environments on Linux to ensure zero-downtime queue handling, synchronized state with BPJS national gateway, and fast patient check-in workflows.",
      impact: "Handled patient queue flows with 99.9% uptime and zero synchronization drops during peak hospital hours.",
      technologies: ["Docker", "Linux", "PHP / Laravel", "BPJS API", "Tailwind CSS", "Figma", "MySQL"],
      year: "2024 — 2025",
      role: "System Architecture, DevOps & Front-End Support",
      client: "RSU Queen Latifa Yogyakarta",
      featured: true,
      metrics: [
        { label: "Deployment", value: "Docker Linux" },
        { label: "Integration", value: "BPJS Gateway" },
        { label: "Target Uptime", value: "99.9%" }
      ],
      accentColor: "#00F2FE",
      architectureDetails: [
        "Multi-service Docker Compose architecture isolating API proxy and worker nodes",
        "Automated health checks and self-healing container policies on Linux host",
        "Secure TLS-encrypted bridging between clinic database and BPJS national gateway"
      ],
      securityConsiderations: [
        "Protected healthcare patient PII with strict environment parameterization",
        "Hardened Nginx reverse proxy with IP rate limiting on bridging endpoints"
      ]
    },
    {
      id: "project-02",
      number: "02",
      title: "Talkshow Event Poster & Brand Visuals",
      category: "EVENT POSTER / BRAND SYSTEMS",
      tag: "DESIGN",
      image: "/images/poster_talkshow_trace_the_truth.webp",
      secondaryImage: "/images/social_pmb_1.webp",
      galleryImages: [
        "/images/poster_talkshow_trace_the_truth.webp",
        "/images/social_pmb_1.webp",
        "/images/social_pmb_2.webp",
        "/images/print_banner_horizontal.webp"
      ],
      shortDescription:
        "Designed high-impact event posters, promotional campaigns, and brand visuals with bold duotone lighting and editorial typography.",
      fullDescription:
        "Directed visual assets for campus talkshows including 'Trace The Truth', food & culinary brand visuals, and university academic media. Created 350+ social carousels, event posters, scholarship promotions, and event banners maintaining strong typographic hierarchy and striking contrast.",
      impact: "Delivered memorable visual campaigns with high attendance engagement and distinct brand presence.",
      technologies: ["Adobe Photoshop", "Adobe Illustrator", "Canva Pro", "Figma", "Duotone Lighting"],
      year: "2024 — 2026",
      role: "Lead Graphic Designer & Visual Director",
      client: "Universitas 'Aisyiyah Yogyakarta & Freelance",
      featured: true,
      metrics: [
        { label: "Creative Assets", value: "350+ Items" },
        { label: "Production", value: "Event & Brand" },
        { label: "Engagement Lift", value: "+185%" }
      ],
      accentColor: "#4FACFE",
      architectureDetails: [
        "High-contrast red and black duotone lighting treatment for key speaker portraits",
        "Modular typography and bold headline hierarchy optimized for print and social feeds",
        "Multi-channel asset rollouts spanning Instagram feeds, stories, and printed promotional media"
      ]
    },
    {
      id: "project-03",
      number: "03",
      title: "Keylogger Attack Forensics on CMS (NIST SP 800-86)",
      category: "DIGITAL FORENSICS / CYBERSECURITY",
      tag: "CYBERSECURITY",
      image: "/images/social_poster_3.webp",
      galleryImages: ["/images/social_poster_3.webp"],
      shortDescription:
        "Published digital forensic research investigating fileless database-injected keylogger malware on WordPress with NIST SP 800-86 and MITRE ATT&CK.",
      fullDescription:
        "Conducted a comprehensive forensic investigation on database-injected keylogger malware. Applied the 4-phase NIST SP 800-86 standard (Collection, Examination, Analysis, Reporting) and mapped malicious execution across MITRE ATT&CK tactics in the `wp_options` table.",
      impact: "Discovered stealthy persistence mechanisms in CMS databases and formulated an automated hardening mitigation standard.",
      technologies: ["Digital Forensics", "NIST SP 800-86", "MITRE ATT&CK", "WordPress Security", "SQL Forensics", "Malware Analysis"],
      year: "2024",
      role: "Lead Forensic Researcher & Analyst",
      featured: true,
      metrics: [
        { label: "Methodology", value: "NIST SP 800-86" },
        { label: "Framework", value: "MITRE ATT&CK" },
        { label: "Artifact Layer", value: "wp_options DB" }
      ],
      accentColor: "#10B981",
      architectureDetails: [
        "Identified obfuscated base64 payload hooks inside autoload SQL records",
        "Reconstructed full attack timeline verifying timestamp manipulation (timestomping)",
        "Comparative security evaluation of plugin attack surfaces versus AI-assisted modern systems"
      ],
      securityConsiderations: [
        "Immutable bitstream image extraction preserving verifiable SHA-256 chain of custody",
        "Automated database integrity verification scripts to detect unauthorized hook injections"
      ]
    },
    {
      id: "project-04",
      number: "04",
      title: "Print Media & Kaos Pro Apparel Design",
      category: "PRINT DESIGN / BRAND MERCHANDISE",
      tag: "DESIGN",
      image: "/images/print_banner_horizontal.webp",
      secondaryImage: "/images/print_kaos_pro_1.webp",
      galleryImages: [
        "/images/print_banner_horizontal.webp",
        "/images/print_xbanner.webp",
        "/images/print_kaos_pro_1.webp",
        "/images/print_kaos_pro_2.webp"
      ],
      shortDescription:
        "Engineered large-format 6x1.75m workshop banners, roll-up X-banners, and custom typography apparel collections.",
      fullDescription:
        "Led creative direction at Kaos Pro Gresik and designed university event collaterals. Delivered print-ready CMYK vector designs with color separations for screen printing and large-scale industrial printing.",
      impact: "Produced 100% production-ready print graphics for national seminars, exhibitions, and custom clothing lines.",
      technologies: ["Adobe Illustrator", "Adobe Photoshop", "Canva", "Screen Print Prep", "CMYK Calibration"],
      year: "2021 — 2024",
      role: "Chief Design Officer & Creative Specialist",
      client: "Kaos Pro & Institutional Clients",
      featured: true,
      metrics: [
        { label: "Max Print Scale", value: "6 x 1.75 m" },
        { label: "Color Accuracy", value: "100% CMYK" },
        { label: "Apparel Lines", value: "20+ Editions" }
      ],
      accentColor: "#818CF8",
      architectureDetails: [
        "Vector typography crafted specifically for screen printing fabric stretch tolerances",
        "Calibrated CMYK color profiles ensuring zero tone drift across vinyl and fabric outputs",
        "Hierarchical typography readable from over 15 meters in exhibition halls"
      ]
    }
  ],

  expertise: [
    {
      id: "design",
      pillar: "DESIGN",
      headline: "Visual Communication & Brand Direction",
      tagline: "Aesthetic Precision × Multi-Channel Narrative",
      accent: "from-cyan-500/20 via-blue-500/10 to-transparent",
      image: "/images/social_pmb_1.webp",
      description:
        "Developing cohesive visual identities, marketing campaigns, editorial layouts, and digital product UI/UX with meticulous composition and typography.",
      skills: [
        "Adobe Photoshop",
        "Adobe Illustrator",
        "Figma (UI/UX)",
        "Canva Pro",
        "Adobe Lightroom",
        "Social Media Management",
        "Print & Apparel Design",
        "Photography (Sony / Fujifilm)",
        "Copywriting & Content Strategy"
      ],
      disciplines: [
        "Multi-Account Social Media Direction",
        "Institutional Campaign & Admission Assets",
        "UI / UX Wireframing & Prototyping",
        "Large Format Print (6x1.75m Banners)",
        "Studio & Cinematic Color Grading"
      ],
      icon: "Palette"
    },
    {
      id: "build",
      pillar: "BUILD",
      headline: "Web Development & DevOps Architecture",
      tagline: "Full-Stack Precision × Containerized Systems",
      accent: "from-blue-500/20 via-indigo-500/10 to-transparent",
      image: "/images/project_vitalife_web.webp",
      description:
        "Building scalable web applications, custom WordPress portals, Laravel backend services, and automated Dockerized deployment environments on Linux.",
      skills: [
        "PHP / Laravel Framework",
        "JavaScript / TypeScript",
        "WordPress Custom CMS",
        "MySQL & SQL Data Modeling",
        "Docker & Docker Compose",
        "Linux (Debian / Ubuntu / Nginx)",
        "HTML5 & Tailwind CSS",
        "Git Version Control & CI/CD",
        "REST API Integration (BPJS)"
      ],
      disciplines: [
        "Enterprise WordPress Portal Engineering",
        "Healthcare Systems Bridging (BPJS Services)",
        "Multi-Service Docker Containerization",
        "Relational Database Optimization",
        "Server Hardening & Automated Deployment"
      ],
      icon: "Code2"
    },
    {
      id: "secure",
      pillar: "SECURE",
      headline: "Cybersecurity & Incident Forensics",
      tagline: "CSIRT Operations × NIST SP 800-86 Method",
      accent: "from-emerald-500/20 via-cyan-500/10 to-transparent",
      description:
        "Protecting web platforms, conducting incident analysis with CSIRT, dissecting fileless malware artifacts, and performing proactive threat surface audits.",
      skills: [
        "CSIRT Incident Triage",
        "Digital Forensics (NIST SP 800-86)",
        "MITRE ATT&CK Framework",
        "Web Security (OWASP Top 10)",
        "OSINT & Reconnaissance",
        "Network Packet Analysis (Wireshark)",
        "Linux Server Hardening",
        "CTF Problem Solving (Gemastik)",
        "WordPress Attack Surface Hardening"
      ],
      disciplines: [
        "Institutional Security Incident Response (BPTSI CSIRT)",
        "Fileless Malware Artifact Recovery (wp_options)",
        "Passive OSINT & Infrastructure Footprinting",
        "Zero-Trust Policy Enactments & RBAC Controls",
        "Penetration Testing Methodology (Sibermuda)"
      ],
      icon: "ShieldAlert"
    }
  ],

  securityLab: {
    title: "SECURITY LAB & RESEARCH",
    subtitle: "Investigating vulnerabilities. Dissecting attack chains. Building fortified defenses.",
    description:
      "A technical research sandbox reflecting real-world incident response at BPTSI CSIRT, digital forensics on CMS environments (NIST SP 800-86), and defensive application hardening.",
    modules: [
      {
        id: "forensics",
        category: "DIGITAL FORENSICS",
        title: "Keylogger & Malware Artifact Extraction (NIST SP 800-86)",
        status: "VERIFIED",
        cveOrStandard: "NIST SP 800-86 / MITRE ATT&CK",
        summary:
          "Systematic forensic reconstruction of fileless database-injected keylogger attacks in CMS environments (wp_options table).",
        details:
          "Four-phase forensic protocol: Acquisition with SHA-256 integrity verification, Examination of obfuscated payload strings, Analysis of MITRE ATT&CK persistence techniques, and Structured Incident Reporting.",
        findings: [
          "Identification of malicious autoload records hiding base64-encoded JavaScript keyloggers",
          "Reconstruction of exfiltration endpoints transmitting keystroke buffers via asynchronous HTTP POST",
          "Verification of non-tampered evidence using cryptographic hashes"
        ],
        mitigations: [
          "Automated database integrity sweeps auditing newly added autoload records in wp_options",
          "Enforce strict Content-Security-Policy (CSP) restricting unauthorized external script execution",
          "Read-only database permissions for non-administrative database user accounts"
        ],
        commandSample: "sha256sum disk_dump.raw && mysql -u root -p -e 'SELECT option_name FROM wp_options WHERE autoload=\"yes\";'",
        attackChainDiagram: [
          { step: "01", label: "Initial Access", desc: "Vulnerable Plugin Vector" },
          { step: "02", label: "Persistence", desc: "wp_options Autoload Hook" },
          { step: "03", label: "Collection", desc: "Keystroke Buffer Capture" },
          { step: "04", label: "Exfiltration", desc: "Encrypted HTTP POST Stream" }
        ]
      },
      {
        id: "web-sec",
        category: "WEB SECURITY",
        title: "OWASP Top 10 Hardening & BPJS API Security",
        status: "HARDENED",
        cveOrStandard: "OWASP Top 10 / Healthcare API Standards",
        summary:
          "Defensive testing and endpoint hardening for bridging architectures, protecting healthcare PII and web applications.",
        details:
          "Enforcing parameterized database binding to prevent SQLi, mitigating XSS via strict output encoding, configuring HTTPS/TLS encryption for bridging payloads, and applying rate limits on authentication routes.",
        findings: [
          "Zero SQL Injection exposure through strict Eloquent ORM & prepared statements",
          "Hardened session management with HttpOnly, Secure, and SameSite=Strict cookies",
          "Eliminated cross-site data leakage in hospital queue bridging routes"
        ],
        mitigations: [
          "Implement fail2ban and Nginx connection throttling for sensitive API routes",
          "Strict HTTP response headers (X-Frame-Options: DENY, X-Content-Type-Options: nosniff)",
          "Enforce TLS 1.3 encryption across all internal microservice bridges"
        ],
        commandSample: "curl -I -X GET https://queue.rsqueenlatifa.com/api/v1/health | grep -iE 'strict|content-security|x-'",
        attackChainDiagram: [
          { step: "01", label: "Ingress", desc: "TLS 1.3 Reverse Proxy" },
          { step: "02", label: "Auth Gate", desc: "Strict Token Rotation" },
          { step: "03", label: "Validation", desc: "Parameterized Binding" },
          { step: "04", label: "Bridging", desc: "Secure BPJS Gateway" }
        ]
      },
      {
        id: "osint",
        category: "OSINT",
        title: "Threat Surface Profiling & Passive Reconnaissance",
        status: "OPTIMIZED",
        cveOrStandard: "OSINT Framework & Gemastik CTF Protocols",
        summary:
          "Non-intrusive intelligence mapping across subdomains, DNS records, public metadata, and exposed certificates.",
        details:
          "Gathering actionable threat intelligence to discover orphan DNS entries, misconfigured staging environments, and accidental credential leaks without invasive probing.",
        findings: [
          "Discovery of dangling CNAME entries vulnerable to subdomain takeover",
          "Identification of metadata fingerprints in public PDF documents revealing internal software versions",
          "Mapping of institutional network boundaries and exposed service ports"
        ],
        mitigations: [
          "Automated git commit scanning using TruffleHog to prevent secret leaks",
          "Routine DNS record cleanup and domain verification audits",
          "Metadata stripping on all publicly published promotional and institutional documents"
        ],
        commandSample: "subfinder -d target.ac.id -silent | httpx -title -status-code -tech-detect",
        attackChainDiagram: [
          { step: "01", label: "DNS Audit", desc: "Passive Subdomain Scan" },
          { step: "02", label: "Certificate", desc: "CT Log Transparency" },
          { step: "03", label: "Metadata", desc: "Exif & Version Fingerprint" },
          { step: "04", label: "Remediation", desc: "DMARC & Secret Shield" }
        ]
      },
      {
        id: "network-sec",
        category: "NETWORK SECURITY",
        title: "Docker Isolation & Traffic Inspection",
        status: "HARDENED",
        cveOrStandard: "Wireshark / Docker Networking Standards",
        summary:
          "Microservice network segmentation, traffic packet inspection, and least-privilege container execution.",
        details:
          "Designing isolated Docker bridge networks to prevent lateral container movement, auditing packet captures for cleartext data exposure, and enforcing firewall ingress rules.",
        findings: [
          "Complete container network isolation preventing unauthorized database direct access",
          "Verification of encrypted payload streams between queue microservices and external gateways",
          "Implementation of non-root user execution in all custom Dockerfiles"
        ],
        mitigations: [
          "Deploy custom internal bridge networks in Docker Compose (internal: true)",
          "Enforce UFW firewall rules allowing only necessary port exposures (80, 443, SSH key-only)",
          "Automated log shipping with timestamp synchronization via NTP"
        ],
        commandSample: "docker network inspect queue_app_bridge && tshark -i docker0 -f 'tcp port 8080'",
        attackChainDiagram: [
          { step: "01", label: "Network Tap", desc: "Docker Bridge Monitor" },
          { step: "02", label: "Packet Parse", desc: "PCAP Stream Decrypt" },
          { step: "03", label: "Policy Check", desc: "Non-Root Isolation" },
          { step: "04", label: "Hardened Host", desc: "Strict UFW Ruleset" }
        ]
      }
    ]
  },

  philosophy: [
    {
      step: "01",
      name: "UNDERSTAND",
      label: "Context & System Discovery",
      summary: "Deconstruct core objectives, audience behavior, attack surfaces, and requirements.",
      quote: "Before designing an asset or writing code, understand the context and potential failure modes.",
      deliverables: ["Audience Persona & Brief", "Architecture Blueprint", "Threat Modeling"]
    },
    {
      step: "02",
      name: "DESIGN",
      label: "Visual Logic & Order",
      summary: "Transform complex messages into clear, high-impact visual hierarchies and UI/UX systems.",
      quote: "Design is not superficial decoration; it is the visual logic that makes systems effortless.",
      deliverables: ["Figma UI / UX Systems", "Typography & Color Palettes", "Campaign Asset Suites"]
    },
    {
      step: "03",
      name: "BUILD",
      label: "Modular Engineering & DevOps",
      summary: "Implement robust web applications, CMS platforms, and containerized deployment pipelines.",
      quote: "Reliable code, clean database schemas, and fast page speeds are non-negotiable foundations.",
      deliverables: ["PHP / Laravel & WordPress Code", "Docker Container Deployments", "Optimized Database Schemas"]
    },
    {
      step: "04",
      name: "SECURE",
      label: "Resilience & Hardening",
      summary: "Audit endpoints, apply defensive configurations, and ensure data integrity under real-world scrutiny.",
      quote: "True craftsmanship anticipates what happens when systems are tested—and engineers resilience by default.",
      deliverables: ["NIST SP 800-86 Forensics", "OWASP Surface Mitigations", "CSIRT Triage Protocols"]
    }
  ],

  techStack: {
    categories: [
      {
        name: "CREATIVE & DESIGN",
        description: "Visual identity, campaign art direction, typography, and photography",
        skills: [
          { name: "Adobe Photoshop", level: "Advanced", desc: "Digital composition, retouching & creative manipulation" },
          { name: "Adobe Illustrator", level: "Advanced", desc: "Vector graphics, branding & institutional iconography" },
          { name: "Figma", level: "Proficient", desc: "UI/UX wireframes, design systems & interactive prototypes" },
          { name: "Canva Pro", level: "Expert", desc: "High-speed marketing campaign and social collateral production" },
          { name: "Adobe Lightroom", level: "Advanced", desc: "Color grading & cinematic photo mastering" },
          { name: "Photography", level: "Camera Ops", desc: "Sony A6300 & Fujifilm X-S20 portrait and product shoots" },
          { name: "Typography & Layout", level: "Editorial", desc: "Hierarchy, readability, print setup (6x1.75m banners)" }
        ]
      },
      {
        name: "WEB & APPLICATION DEVELOPMENT",
        description: "Modern web engineering, backend logic, and CMS management",
        skills: [
          { name: "PHP", level: "Advanced", desc: "Backend scripting, custom WordPress hooks & REST APIs" },
          { name: "Laravel", level: "Framework", desc: "MVC architecture, routing, Eloquent ORM & middleware" },
          { name: "JavaScript / TypeScript", level: "Full-Stack", desc: "Dynamic UI components, state logic & modern ES6+" },
          { name: "WordPress CMS", level: "Specialist", desc: "Custom theme development, portal management & optimization" },
          { name: "MySQL / SQL", level: "Database", desc: "Relational modeling, query optimization & data validation" },
          { name: "HTML5 / Tailwind CSS", level: "Modern", desc: "Responsive glassmorphism, flex/grid & clean layouts" }
        ]
      },
      {
        name: "INFRASTRUCTURE & DEVOPS",
        description: "Container orchestration, server environments, and deployment pipelines",
        skills: [
          { name: "Docker & Compose", level: "Containerized", desc: "Multi-container setups, bridging & reproducible envs" },
          { name: "Linux (Debian / Ubuntu)", level: "SysAdmin", desc: "CLI operations, server configurations & service management" },
          { name: "Git & GitHub", level: "Workflow", desc: "Version control, branching strategies & repo maintenance" },
          { name: "Nginx Reverse Proxy", level: "Deployment", desc: "SSL/TLS termination, rate limiting & host routing" },
          { name: "BPJS Bridging API", level: "Integration", desc: "Healthcare system data exchange & service synchronization" }
        ]
      },
      {
        name: "CYBERSECURITY & FORENSICS",
        description: "Incident response, forensic analysis, and threat intelligence",
        skills: [
          { name: "Digital Forensics", level: "NIST Standard", desc: "NIST SP 800-86 methodology & database artifact analysis" },
          { name: "CSIRT Operations", level: "Analyst", desc: "Incident triage, troubleshooting & system assessments" },
          { name: "MITRE ATT&CK", level: "Mapping", desc: "Adversary tactic & technique behavioral classification" },
          { name: "OWASP Top 10", level: "Hardening", desc: "Web attack surface mitigation (SQLi, XSS, CSRF, CSP)" },
          { name: "OSINT & Recon", level: "Intelligence", desc: "Passive footprinting, subdomain discovery & threat profiling" },
          { name: "Capture The Flag (CTF)", level: "Gemastik", desc: "National-level CTF problem solving & security challenges" }
        ]
      }
    ]
  },

  experience: [
    {
      id: "exp-01",
      period: "March 2024 — Present",
      role: "Cybersecurity Incident Support & IT Operations",
      company: "BPTSI CSIRT — Universitas 'Aisyiyah Yogyakarta",
      location: "Yogyakarta, Indonesia",
      badge: "Active CSIRT",
      logo: "/icons/unisa-emblem.png",
      description:
        "Supporting cybersecurity operations, incident analysis, vulnerability assessments, and infrastructure maintenance within the university's CSIRT team.",
      achievements: [
        "Analyzed technical and security incidents across institutional infrastructure",
        "Conducted system assessments and applied defensive hardening principles",
        "Prepared technical documentation and mitigation action plans"
      ],
      skills: ["Cybersecurity", "Incident Analysis", "CSIRT", "Forensics", "Troubleshooting"]
    },
    {
      id: "exp-02",
      period: "April 2024 — Present",
      role: "Manager Digital Marketing",
      company: "HITS Software House",
      location: "Yogyakarta, Indonesia",
      badge: "Creative Management",
      logo: "/icons/hits-symbol.svg",
      description:
        "Managing digital marketing strategy, visual branding pipelines, promotional campaigns, and WordPress web architecture for HITS Software House.",
      achievements: [
        "Produced 350+ digital visual assets (social media, admission posters, banners)",
        "Managed content planning and publication calendars across multiple client accounts",
        "Maintained WordPress websites, landing pages, and promotional campaigns"
      ],
      skills: ["Digital Marketing", "Graphic Design", "Brand Strategy", "Adobe Suite", "WordPress", "Meta Ads"]
    },
    {
      id: "exp-03",
      period: "October 2024 — January 2025",
      role: "System Architecture & DevOps Support",
      company: "BPJS Bridging & Online Queue System — RSU Queen Latifa",
      location: "Yogyakarta, Indonesia",
      badge: "Healthcare Engineering",
      description:
        "Contributed to system architecture design, Docker deployment, and front-end integration for an online queueing system connected to BPJS.",
      achievements: [
        "Architected multi-service Docker container deployment on Linux server",
        "Implemented responsive front-end components matching hospital workflow",
        "Maintained system reliability and zero downtime during live bridging"
      ],
      skills: ["System Architecture", "Docker", "Linux", "DevOps", "BPJS API", "Front-End"]
    },
    {
      id: "exp-04",
      period: "November 2021 — July 2023",
      role: "Chief Design Officer",
      company: "Kaos Pro",
      location: "Gresik, Indonesia",
      badge: "Brand Leadership",
      description:
        "Led creative direction and visual communication strategies to strengthen brand identity and custom apparel production.",
      achievements: [
        "Translated client requirements into high-impact apparel and typography designs",
        "Managed design workflows through final production-ready print setup",
        "Supported social media visual presence and customer engagement"
      ],
      skills: ["Creative Direction", "Apparel Design", "Illustrator", "Photoshop", "Print Production"]
    }
  ],

  publications: [
    {
      id: "pub-01",
      title: "Digital Forensic Analysis of Keylogger Attack Evidence on Websites Using the NIST Method",
      journal: "Prisma Sains : Jurnal Pengkajian Ilmu Dan Pembelajaran Matematika Dan IPA IKIP Mataram",
      year: "2026",
      volume: "Vol. 14 No. 2 (2026): 412–435",
      doi: "10.33394/j-ps.v14i2.19919",
      doiUrl: "https://doi.org/10.33394/j-ps.v14i2.19919",
      category: "CYBERSECURITY & FORENSICS",
      authors: ["Arizona Firdonsyah", "Dimas Rizki Setyaji"],
      summary:
        "Investigasi forensik digital pada website WordPress yang terinfeksi fileless keylogger menggunakan kerangka kerja NIST SP 800-86 (Collection, Examination, Analysis, Reporting) yang dipetakan ke taktik MITRE ATT&CK.",
      keyFindings: [
        "Identifikasi injeksi fileless keylogger berbasis manipulasi tabel database wp_options",
        "Pemetaan taktik MITRE ATT&CK: Initial Access (TA0001), Persistence (TA0003), Collection (T1056.001), & Exfiltration (TA0010)",
        "Audit komparatif membuktikan 97% celah keamanan WordPress berasal dari plugin pihak ketiga"
      ],
      tags: ["Digital Forensics", "NIST SP 800-86", "Keylogger", "WordPress Security", "MITRE ATT&CK", "Database Audit"]
    },
    {
      id: "pub-02",
      title: "Perancangan Arsitektur Sistem Antrian Online Terintegrasi BPJS di RSU Queen Latifa Berbasis Docker",
      journal: "Jurnal Teknik Mesin, Industri, Elektro Dan Informatika (JTMEI)",
      year: "2025",
      volume: "Vol. 4 No. 2 (2025): 32–40",
      doi: "10.55606/jtmei.v4i2.4890",
      doiUrl: "https://doi.org/10.55606/jtmei.v4i2.4890",
      category: "CONTAINERIZATION & DEVOPS",
      authors: ["Dimas Rizki Setyaji", "Danur Wijayanto"],
      summary:
        "Perancangan arsitektur sistem antrian rumah sakit terintegrasi API BPJS Kesehatan menggunakan teknologi kontainerisasi Docker dan virtualisasi server Proxmox dengan pipeline CI/CD GitHub Actions.",
      keyFindings: [
        "Isolasi multi-kontainer Docker memastikan stabilitas dan kompatibilitas lintas platform",
        "Integrasi antrean real-time dengan BPJS Vclaim & Bridging API pada infrastruktur Proxmox",
        "Implementasi otomatisasi CI/CD via GitHub Actions untuk deployment minim downtime"
      ],
      tags: ["Docker Container", "BPJS Bridging API", "Proxmox", "System Architecture", "CI/CD GitHub Actions", "Healthcare IT"]
    }
  ],

  achievements: [
    {
      year: "2024",
      title: "Silver Medal — Rakornas AST PTMA Yogyakarta",
      category: "Software Application Development",
      award: "Silver Medal (National)",
      description: "National award for software application development performance and innovation."
    },
    {
      year: "2023",
      title: "Silver Medal — Rakornas AST PTMA Bukittinggi",
      category: "Software Application Development",
      award: "Silver Medal (National)",
      description: "National recognition for software engineering and system development."
    },
    {
      year: "2025",
      title: "Participant — Gemastik 2025",
      category: "Cyber Security / CTF",
      award: "National Finalist / Participant",
      description: "National cybersecurity competition focused on Capture The Flag (CTF) challenges."
    },
    {
      year: "2022 & 2023",
      title: "Participant — Gemastik 2022 & 2023",
      category: "UI / UX Design",
      award: "National Competitor",
      description: "National competition focused on digital product design and Figma prototyping."
    }
  ],

  education: [
    {
      institution: "Universitas 'Aisyiyah Yogyakarta",
      degree: "Bachelor of Information Technology (S.Tr.Kom / S.Kom)",
      period: "2022 — 2026",
      focus: "Information Systems, Database Management, DevOps, Information Security & Digital Forensics"
    },
    {
      institution: "SMKN 1 Cerme Gresik",
      degree: "Vocational High School — Multimedia Major",
      period: "2019 — 2022",
      focus: "Graphic Design, Vector Illustration, Photography, Print Media & Video Production"
    }
  ]
};
