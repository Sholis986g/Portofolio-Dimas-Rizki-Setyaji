'use client';

import React from 'react';
import { motion } from 'framer-motion';
import Image from 'next/image';
import Link from 'next/link';
import {
  ShieldCheck,
  Palette,
  Code2,
  Award,
  BookOpen,
  ArrowRight,
  ExternalLink,
  MapPin,
  Clock,
  Briefcase,
  Layers,
  Sparkles
} from 'lucide-react';
import { PORTFOLIO_DATA } from '@/data/portfolio-data';
import { useApp } from '@/context/AppContext';
import { DICTIONARY } from '@/data/translations';

export default function About() {
  const { profile } = PORTFOLIO_DATA;
  const { language, theme } = useApp();
  const t = DICTIONARY[language].about;

  return (
    <section id="about" className="py-20 md:py-28 relative border-t border-zinc-200 dark:border-white/[0.08]">
      {/* Ambient background glow */}
      <div className="absolute top-1/3 left-1/4 -translate-x-1/2 -translate-y-1/2 w-[550px] h-[450px] bg-cyan-500/5 dark:bg-cyan-500/10 blur-[150px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 w-[450px] h-[350px] bg-purple-500/5 dark:bg-purple-500/10 blur-[150px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-6 md:px-12 relative z-10">
        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-12 gap-4 pb-4 border-b border-zinc-200 dark:border-white/[0.06]">
          <div>
            <div className="flex items-center gap-2.5 mb-2">
              <span className="h-2 w-2 rounded-full bg-cyan-400 animate-pulse" />
              <span className="text-xs font-mono-code uppercase tracking-[0.25em] text-cyan-600 dark:text-cyan-400 font-bold">
                {t.eyebrow}
              </span>
            </div>
            <h2 className="text-3xl sm:text-4xl md:text-5xl font-editorial font-extrabold tracking-tight text-zinc-950 dark:text-white">
              DIMAS RIZKI SETYAJI
            </h2>
          </div>
          <span className="text-xs font-mono-code text-zinc-600 dark:text-zinc-400 font-semibold">
            {t.sub}
          </span>
        </div>

        {/* 2-Column Professional Architecture */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* LEFT COLUMN: Profile Authority, Institutional Affiliations & Status (5 cols) */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="lg:col-span-5 rounded-3xl cyber-card p-6 sm:p-7 shadow-xs space-y-6"
          >
            {/* Header: Photo + Name + Verified Badge */}
            <div className="flex items-center gap-4.5 pb-5 border-b border-zinc-200 dark:border-white/[0.06]">
              <div className="relative w-20 h-20 sm:w-22 sm:h-22 rounded-2xl overflow-hidden border-2 border-cyan-500/60 shrink-0 shadow-md">
                <Image
                  src={profile.avatar}
                  alt={profile.name}
                  fill
                  sizes="88px"
                  className="object-cover"
                />
              </div>
              <div className="min-w-0">
                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-100/90 dark:bg-emerald-500/10 border border-emerald-300 dark:border-emerald-500/30 text-emerald-800 dark:text-emerald-400 text-[10.5px] font-mono-code font-bold mb-1.5 shadow-xs">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-ping" />
                  PROFIL TERVERIFIKASI
                </div>
                <h3 className="text-xl sm:text-2xl font-editorial font-bold text-zinc-950 dark:text-white truncate">
                  {profile.name}
                </h3>
                <p className="text-xs font-mono-code text-zinc-600 dark:text-zinc-400 font-medium mt-0.5 truncate">
                  {t.eduShort}
                </p>
              </div>
            </div>

            {/* Official Affiliation Cards */}
            <div className="space-y-3">
              <div className="text-[11px] font-mono-code font-bold uppercase tracking-widest text-zinc-500 dark:text-zinc-400">
                AFILIASI RESMI & PERAN
              </div>

              {/* HITS Software House Card */}
              <div className="flex items-center gap-3.5 p-3 rounded-2xl bg-zinc-50 dark:bg-white/[0.02] border border-zinc-200 dark:border-white/10 shadow-xs">
                <div className="relative w-12 h-12 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-white/10 p-1.5 shrink-0 flex items-center justify-center overflow-hidden">
                  <Image
                    src="/icons/hits-symbol.svg"
                    alt="HITS Software House"
                    width={40}
                    height={40}
                    className="object-contain"
                  />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-xs font-mono-code font-bold text-zinc-950 dark:text-white truncate">
                    {t.orgHits}
                  </div>
                  <div className="text-[11px] font-mono-code text-cyan-700 dark:text-cyan-400 font-bold">
                    Manager Digital Marketing
                  </div>
                  <div className="text-[10.5px] font-mono-code text-zinc-500 dark:text-zinc-400">
                    350+ Aset Desain & Web Portal
                  </div>
                </div>
              </div>

              {/* BPTSI CSIRT UNISA Card */}
              <div className="flex items-center gap-3.5 p-3 rounded-2xl bg-zinc-50 dark:bg-white/[0.02] border border-zinc-200 dark:border-white/10 shadow-xs">
                <div className="relative w-12 h-12 rounded-xl bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-white/10 p-1.5 shrink-0 flex items-center justify-center overflow-hidden">
                  <Image
                    src="/icons/unisa-emblem.png"
                    alt="BPTSI CSIRT UNISA"
                    width={40}
                    height={40}
                    className="object-contain"
                  />
                </div>
                <div className="min-w-0 flex-1">
                  <div className="text-xs font-mono-code font-bold text-zinc-950 dark:text-white truncate">
                    {t.orgUnisa}
                  </div>
                  <div className="text-[11px] font-mono-code text-emerald-700 dark:text-emerald-400 font-bold">
                    Analis Aktif CSIRT
                  </div>
                  <div className="text-[10.5px] font-mono-code text-zinc-500 dark:text-zinc-400">
                    Operasi Forensik & Hardening
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Micro-Metadata Grid */}
            <div className="grid grid-cols-3 gap-2.5 pt-4 border-t border-zinc-200 dark:border-white/[0.06]">
              <div className="p-3 rounded-xl bg-zinc-50 dark:bg-white/[0.02] border border-zinc-200 dark:border-white/[0.05]">
                <span className="text-[10.5px] font-mono-code text-cyan-700 dark:text-cyan-400 font-bold block mb-0.5">
                  {t.locLabel}
                </span>
                <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100 truncate block">
                  {t.locValue}
                </span>
              </div>
              <div className="p-3 rounded-xl bg-zinc-50 dark:bg-white/[0.02] border border-zinc-200 dark:border-white/[0.05]">
                <span className="text-[10.5px] font-mono-code text-emerald-700 dark:text-emerald-400 font-bold block mb-0.5">
                  {t.expLabel}
                </span>
                <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100 truncate block">
                  {t.expValue}
                </span>
              </div>
              <div className="p-3 rounded-xl bg-zinc-50 dark:bg-white/[0.02] border border-zinc-200 dark:border-white/[0.05]">
                <span className="text-[10.5px] font-mono-code text-purple-700 dark:text-purple-400 font-bold block mb-0.5">
                  {t.freeLabel}
                </span>
                <span className="text-xs font-bold text-zinc-900 dark:text-zinc-100 truncate block">
                  {t.freeValue}
                </span>
              </div>
            </div>
          </motion.div>

          {/* RIGHT COLUMN: Executive Summary, 4 Achievement Badges, & Research Quicklinks (7 cols) */}
          <div className="lg:col-span-7 space-y-5">
            {/* 4 Core Achievement Badges */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Badge 1: Desain Kreatif */}
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: 0.05 }}
                className="p-5 rounded-2xl cyber-card shadow-xs flex flex-col justify-between"
              >
                <div>
                  <div className="w-9 h-9 rounded-xl bg-cyan-100/90 dark:bg-cyan-500/10 border border-cyan-300 dark:border-cyan-500/20 flex items-center justify-center text-cyan-700 dark:text-cyan-400 mb-3">
                    <Palette className="w-4.5 h-4.5" />
                  </div>
                  <span className="text-[10.5px] font-mono-code text-cyan-700 dark:text-cyan-400 font-bold uppercase tracking-widest block mb-1">
                    {t.creativeTitle}
                  </span>
                  <h4 className="text-base font-editorial font-bold text-zinc-950 dark:text-white mb-1.5">
                    {t.creativeDesc}
                  </h4>
                  <p className="text-xs text-zinc-600 dark:text-zinc-400 font-normal leading-relaxed">
                    {t.creativeStats}
                  </p>
                </div>
                <Link
                  href="/design"
                  className="mt-4 pt-3 border-t border-zinc-200 dark:border-white/[0.06] flex items-center justify-between text-xs font-mono-code font-bold text-cyan-700 dark:text-cyan-400 hover:translate-x-1 transition-transform"
                >
                  <span>{t.openDesignLab}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </motion.div>

              {/* Badge 2: Forensik CSIRT */}
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: 0.1 }}
                className="p-5 rounded-2xl cyber-card cyber-card-emerald shadow-xs flex flex-col justify-between"
              >
                <div>
                  <div className="w-9 h-9 rounded-xl bg-emerald-100/90 dark:bg-emerald-500/10 border border-emerald-300 dark:border-emerald-500/20 flex items-center justify-center text-emerald-700 dark:text-emerald-400 mb-3">
                    <ShieldCheck className="w-4.5 h-4.5" />
                  </div>
                  <span className="text-[10.5px] font-mono-code text-emerald-700 dark:text-emerald-400 font-bold uppercase tracking-widest block mb-1">
                    {t.secTitle}
                  </span>
                  <h4 className="text-base font-editorial font-bold text-zinc-950 dark:text-white mb-1.5">
                    {t.secDesc}
                  </h4>
                  <p className="text-xs text-zinc-600 dark:text-zinc-400 font-normal leading-relaxed">
                    {t.secStats}
                  </p>
                </div>
                <Link
                  href="/security"
                  className="mt-4 pt-3 border-t border-zinc-200 dark:border-white/[0.06] flex items-center justify-between text-xs font-mono-code font-bold text-emerald-700 dark:text-emerald-400 hover:translate-x-1 transition-transform"
                >
                  <span>{t.openSecurityLab}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </Link>
              </motion.div>

              {/* Badge 3: Prestasi Nasional */}
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: 0.15 }}
                className="p-5 rounded-2xl cyber-card shadow-xs flex flex-col justify-between"
              >
                <div>
                  <div className="w-9 h-9 rounded-xl bg-amber-100/90 dark:bg-amber-500/10 border border-amber-300 dark:border-amber-500/20 flex items-center justify-center text-amber-700 dark:text-amber-400 mb-3">
                    <Award className="w-4.5 h-4.5" />
                  </div>
                  <span className="text-[10.5px] font-mono-code text-amber-700 dark:text-amber-400 font-bold uppercase tracking-widest block mb-1">
                    {t.awardsTitle}
                  </span>
                  <h4 className="text-base font-editorial font-bold text-zinc-950 dark:text-white mb-1.5">
                    {t.awardsSub}
                  </h4>
                  <p className="text-xs text-zinc-600 dark:text-zinc-400 font-normal leading-relaxed">
                    {t.awardsDesc}
                  </p>
                </div>
                <span className="text-[10.5px] font-mono-code text-zinc-500 font-semibold mt-4">AST PTMA NATIONAL</span>
              </motion.div>

              {/* Badge 4: Full-Stack & DevOps */}
              <motion.div
                initial={{ opacity: 0, y: 15 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: 0.2 }}
                className="p-5 rounded-2xl cyber-card shadow-xs flex flex-col justify-between"
              >
                <div>
                  <div className="w-9 h-9 rounded-xl bg-indigo-100/90 dark:bg-indigo-500/10 border border-indigo-300 dark:border-indigo-500/20 flex items-center justify-center text-indigo-700 dark:text-indigo-400 mb-3">
                    <Code2 className="w-4.5 h-4.5" />
                  </div>
                  <span className="text-[10.5px] font-mono-code text-indigo-700 dark:text-indigo-400 font-bold uppercase tracking-widest block mb-1">
                    {t.devTitle}
                  </span>
                  <h4 className="text-base font-editorial font-bold text-zinc-950 dark:text-white mb-1.5">
                    {t.devSub}
                  </h4>
                  <p className="text-xs text-zinc-600 dark:text-zinc-400 font-normal leading-relaxed">
                    {t.devDesc}
                  </p>
                </div>
                <span className="text-[10.5px] font-mono-code text-zinc-500 font-semibold mt-4">PHP · LARAVEL · BPJS</span>
              </motion.div>
            </div>

            {/* 2 DOI Publications Quick-Card */}
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: 0.25 }}
              className="p-6 rounded-3xl cyber-card shadow-xs"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-blue-100/90 dark:bg-blue-500/10 border border-blue-300 dark:border-blue-500/20 flex items-center justify-center text-blue-700 dark:text-blue-400">
                    <BookOpen className="w-4.5 h-4.5" />
                  </div>
                  <div>
                    <span className="text-[10.5px] font-mono-code text-blue-700 dark:text-blue-400 font-bold uppercase tracking-widest block">
                      {t.pubTitle}
                    </span>
                    <h4 className="text-base font-editorial font-bold text-zinc-950 dark:text-white">
                      {t.pubDesc}
                    </h4>
                  </div>
                </div>
                <Link
                  href="#publications"
                  className="p-2 rounded-xl bg-zinc-100 dark:bg-white/[0.05] border border-zinc-300 dark:border-transparent hover:bg-cyan-500 hover:text-white transition-colors"
                >
                  <ExternalLink className="w-4 h-4" />
                </Link>
              </div>

              <div className="space-y-2 text-xs font-mono-code">
                <a
                  href="https://doi.org/10.55606/jtmei.v4i2.4890"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 rounded-xl bg-zinc-50 dark:bg-white/[0.02] border border-zinc-200 dark:border-white/[0.05] hover:border-cyan-500 flex items-center justify-between group/paper transition-colors"
                >
                  <span className="text-zinc-800 dark:text-zinc-300 group-hover/paper:text-cyan-700 dark:group-hover/paper:text-cyan-300 font-medium truncate">
                    {t.pubPaper1}
                  </span>
                  <span className="text-[11px] text-cyan-700 dark:text-cyan-400 font-bold shrink-0 ml-2">DOI ↗</span>
                </a>

                <a
                  href="https://doi.org/10.33394/j-ps.v14i2.19919"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 rounded-xl bg-zinc-50 dark:bg-white/[0.02] border border-zinc-200 dark:border-white/[0.05] hover:border-blue-500 flex items-center justify-between group/paper transition-colors"
                >
                  <span className="text-zinc-800 dark:text-zinc-300 group-hover/paper:text-blue-700 dark:group-hover/paper:text-blue-300 font-medium truncate">
                    {t.pubPaper2}
                  </span>
                  <span className="text-[11px] text-blue-700 dark:text-blue-400 font-bold shrink-0 ml-2">DOI ↗</span>
                </a>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
}
